# -*- coding: utf-8 -*-
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import pearsonr, rankdata, spearmanr


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "results" / "metric_selection"
RNG = np.random.default_rng(20261115)


def rho(x, y):
    result = spearmanr(x, y)
    return float(result.statistic), float(result.pvalue)


def partial_rank_rho(y, x, controls):
    data = pd.DataFrame({"y": y, "x": x, **{f"c{i}": c for i, c in enumerate(controls)}}).dropna()
    ry = rankdata(data.y)
    rx = rankdata(data.x)
    z = np.column_stack([np.ones(len(data)), *[rankdata(data[f"c{i}"]) for i in range(len(controls))]])
    ry = ry - z @ np.linalg.lstsq(z, ry, rcond=None)[0]
    rx = rx - z @ np.linalg.lstsq(z, rx, rcond=None)[0]
    result = pearsonr(rx, ry)
    return float(result.statistic), float(result.pvalue)


def main():
    data = pd.read_csv(OUT / "metric_selection_dataset.csv")
    active = data[data.active].copy()
    h = active.deficit_lw_sd_weighted
    gain = active.gain_shared
    rows = []

    for label, frame in [
        ("active_20", active),
        ("active_iid_17", active[active.split.eq("iid")]),
        ("active_no_gas_sensor_drift", active[active.dataset.ne("gas_sensor_drift")]),
        ("active_no_tiny_class_lt30", active[active.minority.ge(30)]),
    ]:
        value, pvalue = rho(frame.deficit_lw_sd_weighted, frame.gain_shared)
        rows.append({"analysis": label, "n": len(frame), "statistic": value, "p_value": pvalue})
    value, pvalue = rho(active.K_metric, gain)
    rows.append({"analysis": "K_alone", "n": len(active), "statistic": value, "p_value": pvalue})
    value, pvalue = partial_rank_rho(gain, h, [active.K_metric])
    rows.append({"analysis": "partial_H_given_K", "n": len(active), "statistic": value, "p_value": pvalue})
    value, pvalue = partial_rank_rho(
        gain,
        h,
        [active.deficit_lw_mean, active.support_min, active.K_metric],
    )
    rows.append({"analysis": "partial_H_given_M0", "n": len(active), "statistic": value, "p_value": pvalue})

    active["quartile"] = pd.qcut(
        active.deficit_lw_sd_weighted,
        4,
        labels=["Q1_low", "Q2", "Q3", "Q4_high"],
    )
    quartiles = active.groupby("quartile", observed=True).agg(
        n=("dataset", "size"),
        mean_H=("deficit_lw_sd_weighted", "mean"),
        mean_gain_shared=("gain_shared", "mean"),
        median_gain_shared=("gain_shared", "median"),
        positive_count=("gain_shared", lambda x: int((x > 0).sum())),
        datasets=("dataset", lambda x: ";".join(x)),
    ).reset_index()
    quartiles.to_csv(OUT / "metric_selection_quartiles.csv", index=False)

    key = pd.DataFrame(rows)
    key.to_csv(OUT / "metric_selection_key_results.csv", index=False)

    # Paired bootstrap for the pre-specified rank-score rule versus always-CSM.
    import sys

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import analyze_metric_selection as A

    choose, _ = A.rank_score_rule_lodo(active, ["deficit_lw_sd_weighted"])
    selected = np.where(choose, gain, 0.0)
    difference = selected - gain.to_numpy(float)
    bootstrap = [difference[RNG.integers(0, len(difference), len(difference))].mean() for _ in range(5000)]
    paired = {
        "rule": "rank_score_H_only",
        "selected_mean_gain_pp": float(selected.mean()),
        "mean_regret_pp": float(np.maximum(0.0, gain.to_numpy(float)).mean() - selected.mean()),
        "mean_difference_rule_minus_always_csm_pp": float(difference.mean()),
        "bootstrap_ci_low": float(np.quantile(bootstrap, 0.025)),
        "bootstrap_ci_high": float(np.quantile(bootstrap, 0.975)),
    }

    stability = pd.read_csv(OUT / "metric_selection_fold_stability.csv")
    rules = pd.read_csv(OUT / "metric_selection_rule_results.csv")
    regressions = pd.read_csv(OUT / "metric_selection_lodo_regression.csv")
    summary = {
        "primary_rho": rows[0]["statistic"],
        "primary_p": rows[0]["p_value"],
        "paired_rule_vs_always_csm": paired,
        "fold_icc_H_ER": float(stability.loc[stability.feature.eq("deficit_lw_sd_weighted"), "icc"].iloc[0]),
        "runtime_note": "26 datasets x 5 folds x 5 seeds, cached fold-level geometry",
    }
    (OUT / "metric_selection_extended_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    lines = [
        "# Extended metric-selection results",
        "",
        "## Key statistics",
        key.to_csv(index=False),
        "## Quartiles of H_ER",
        quartiles.to_csv(index=False),
        "## Paired rule comparison",
        json.dumps(paired, indent=2),
        "## Fold stability",
        stability.to_csv(index=False),
        "## LODO regression",
        regressions.to_csv(index=False),
        "## LODO rules",
        rules.to_csv(index=False),
    ]
    (OUT / "metric_selection_extended_report.md").write_text("\n".join(lines), encoding="utf-8")
    print(key.to_string(index=False))
    print(quartiles.to_string(index=False))
    print(json.dumps(paired, indent=2))


if __name__ == "__main__":
    main()
