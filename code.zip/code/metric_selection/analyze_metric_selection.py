# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.linear_model import Ridge


ROOT = Path(__file__).resolve().parents[2]
HARNESS = ROOT / "code" / "harness"
OUT = ROOT / "results" / "metric_selection"
FIG = OUT / "figures"
RNG = np.random.default_rng(20261115)
sys.path.insert(0, str(HARNESS))
from pr_style import COLORS, set_pr_style


FEATURES = [
    "deficit_lw_mean",
    "deficit_lw_sd_weighted",
    "deficit_lw_sd_unweighted",
    "subspace_heterogeneity_lw",
    "support_min",
    "support_median",
    "fisher_ratio_lw",
    "top1_lw_mean",
    "logcond10_lw_mean",
    "deficit_emp_mean",
    "deficit_emp_sd_weighted",
]


def rho_p(x, y):
    frame = pd.DataFrame({"x": x, "y": y}).dropna()
    if len(frame) < 4 or frame.x.nunique() < 2 or frame.y.nunique() < 2:
        return np.nan, np.nan
    result = spearmanr(frame.x, frame.y)
    return float(result.statistic), float(result.pvalue)


def boot_ci(x, y, n_boot=3000):
    frame = pd.DataFrame({"x": x, "y": y}).dropna().reset_index(drop=True)
    if len(frame) < 5:
        return np.nan, np.nan
    values = []
    for _ in range(n_boot):
        sample = frame.iloc[RNG.integers(0, len(frame), len(frame))]
        if sample.x.nunique() < 2 or sample.y.nunique() < 2:
            continue
        value = spearmanr(sample.x, sample.y).statistic
        if np.isfinite(value):
            values.append(float(value))
    return tuple(np.quantile(values, [0.025, 0.975])) if values else (np.nan, np.nan)


def loo_range(data, xcol, ycol):
    clean = data[[xcol, ycol]].dropna()
    values = []
    for idx in clean.index:
        value, _ = rho_p(clean.loc[clean.index != idx, xcol], clean.loc[clean.index != idx, ycol])
        if np.isfinite(value):
            values.append(value)
    return (min(values), max(values)) if values else (np.nan, np.nan)


def build_dataset_table():
    folds = pd.concat(
        [pd.read_csv(path) for path in sorted((OUT / "fold_cache").glob("*__r8__folds.csv"))],
        ignore_index=True,
    )
    numeric = [
        c for c in folds.columns
        if c not in {"dataset", "split_strategy", "seed", "fold", "seconds", "n_train"}
        and pd.api.types.is_numeric_dtype(folds[c])
    ]
    mean = folds.groupby("dataset")[numeric].mean()
    std = folds.groupby("dataset")[numeric].std(ddof=1).add_suffix("__fold_sd")
    data = mean.join(std)
    outcomes = pd.read_csv(
        ROOT / "results" / "paper_inputs" / "fig_6_4_6_5_data.csv"
    ).set_index("dataset")
    keep = ["split", "gain_shared", "gain_frozen", "delta_shared", "delta_fixed", "K", "d"]
    data = data.join(outcomes[keep], how="inner", rsuffix="_outcome")
    data = data.rename(columns={"d_outcome": "d_metric", "K_outcome": "K_metric"})
    metadata = pd.read_csv(HARNESS / "reports" / "ch6" / "dataset_metadata.csv").set_index("dataset")
    data = data.join(metadata[["minority"]], how="left")
    data["active"] = data["d_metric"] > 8
    data["split"] = data["split"].astype(str)
    data.sort_index().reset_index().to_csv(OUT / "metric_selection_dataset.csv", index=False)
    folds.to_csv(OUT / "metric_selection_folds.csv", index=False)
    return data.sort_index(), folds


def build_correlations(data):
    subsets = {
        "all_26": data,
        "active_20": data[data.active],
        "active_iid_17": data[data.active & data.split.eq("iid")],
        "active_shifted_3": data[data.active & data.split.eq("shifted")],
        "active_no_tiny_class_lt30": data[data.active & data.minority.ge(30)],
    }
    rows = []
    for subset_name, subset in subsets.items():
        for feature in FEATURES:
            for target in ["gain_shared", "gain_frozen"]:
                rho, pvalue = rho_p(subset[feature], subset[target])
                ci_low, ci_high = boot_ci(subset[feature], subset[target])
                loo_low, loo_high = loo_range(subset, feature, target)
                rows.append(
                    {
                        "subset": subset_name,
                        "n": len(subset),
                        "feature": feature,
                        "target": target,
                        "spearman_rho": rho,
                        "p_value": pvalue,
                        "bootstrap_ci_low": ci_low,
                        "bootstrap_ci_high": ci_high,
                        "loo_rho_low": loo_low,
                        "loo_rho_high": loo_high,
                    }
                )
    table = pd.DataFrame(rows)
    table.to_csv(OUT / "metric_selection_correlations.csv", index=False)
    return table


def build_fold_stability(folds, data):
    active_names = set(data.loc[data.active].index)
    subset = folds[folds.dataset.isin(active_names)]
    rows = []
    for feature in ["deficit_lw_mean", "deficit_lw_sd_weighted", "subspace_heterogeneity_lw", "support_min", "fisher_ratio_lw"]:
        frame = subset[["dataset", feature]].dropna()
        group_means = frame.groupby("dataset")[feature].mean()
        within = (frame[feature] - frame.dataset.map(group_means)) ** 2
        within_var = float(within.mean())
        between_var = float(group_means.var(ddof=1))
        total_var = between_var + within_var
        rows.append(
            {
                "feature": feature,
                "between_dataset_variance": between_var,
                "within_dataset_variance": within_var,
                "icc": between_var / total_var if total_var > 0 else np.nan,
                "mean_within_sd": float(np.sqrt(within_var)),
                "mean_dataset_value": float(group_means.mean()),
                "mean_within_cv": float(np.sqrt(within_var) / abs(group_means.mean())) if abs(group_means.mean()) > 0 else np.nan,
            }
        )
    table = pd.DataFrame(rows)
    table.to_csv(OUT / "metric_selection_fold_stability.csv", index=False)
    return table


def lodo_ridge(data, features, target="gain_shared", alpha=1.0):
    prediction = pd.Series(index=data.index, dtype=float)
    for idx in data.index:
        train = data.loc[data.index != idx]
        test = data.loc[[idx]]
        x_train = train[features].to_numpy(float)
        x_test = test[features].to_numpy(float)
        center = x_train.mean(axis=0)
        scale = x_train.std(axis=0, ddof=1)
        scale[scale < 1e-12] = 1.0
        model = Ridge(alpha=alpha).fit((x_train - center) / scale, train[target])
        prediction.loc[idx] = float(model.predict((x_test - center) / scale)[0])
    return prediction


def regression_metrics(y, pred):
    y = np.asarray(y, float)
    pred = np.asarray(pred, float)
    residual = y - pred
    denom = float(np.sum((y - y.mean()) ** 2))
    rho, pvalue = rho_p(y, pred)
    return {
        "mae": float(np.mean(np.abs(residual))),
        "rmse": float(np.sqrt(np.mean(residual**2))),
        "r2": float(1.0 - np.sum(residual**2) / denom) if denom > 0 else np.nan,
        "spearman_rho": rho,
        "p_value": pvalue,
    }


def fit_regressions(data):
    models = {
        "M0_deficit_support_K": ["deficit_lw_mean", "support_min", "K_metric"],
        "M1_plus_H_ER": ["deficit_lw_mean", "support_min", "K_metric", "deficit_lw_sd_weighted"],
        "M2_plus_subspace": [
            "deficit_lw_mean", "support_min", "K_metric",
            "deficit_lw_sd_weighted", "subspace_heterogeneity_lw",
        ],
        "M3_plus_fisher_sensitivity": [
            "deficit_lw_mean", "support_min", "K_metric",
            "deficit_lw_sd_weighted", "subspace_heterogeneity_lw", "fisher_ratio_lw",
        ],
    }
    prediction = data[["split", "gain_shared"]].copy()
    rows = []
    for name, features in models.items():
        pred = lodo_ridge(data, features)
        prediction[name] = pred
        rows.append({"model": name, "features": " + ".join(features), **regression_metrics(data.gain_shared, pred)})
    table = pd.DataFrame(rows)
    table.to_csv(OUT / "metric_selection_lodo_regression.csv", index=False)
    prediction.to_csv(OUT / "metric_selection_lodo_predictions.csv")
    return table, prediction


def selected_mean(gain, choose):
    gain = np.asarray(gain, float)
    choose = np.asarray(choose, bool)
    return float(np.mean(np.where(choose, gain, 0.0)))


def mean_regret(gain, choose):
    gain = np.asarray(gain, float)
    choose = np.asarray(choose, bool)
    oracle = np.maximum(0.0, gain)
    return float(np.mean(oracle - np.where(choose, gain, 0.0)))


def classify_summary(gain, choose):
    gain = np.asarray(gain, float)
    choose = np.asarray(choose, bool)
    actual = gain > 0
    return {
        "selected_mean_gain_pp": selected_mean(gain, choose),
        "mean_regret_pp": mean_regret(gain, choose),
        "oracle_mean_gain_pp": float(np.mean(np.maximum(0.0, gain))),
        "choose_csm_count": int(choose.sum()),
        "true_positive": int(np.sum(choose & actual)),
        "false_positive": int(np.sum(choose & ~actual)),
        "true_negative": int(np.sum(~choose & ~actual)),
        "false_negative": int(np.sum(~choose & actual)),
    }


def single_rule_lodo(data, feature, quantiles=(0.25, 0.50, 0.75)):
    choose = pd.Series(False, index=data.index)
    thresholds = []
    for idx in data.index:
        train = data.loc[data.index != idx]
        test = data.loc[[idx]]
        candidates = []
        for q in np.quantile(train[feature], quantiles):
            mask = train[feature].to_numpy(float) >= q
            candidates.append((selected_mean(train.gain_shared, mask), -int(mask.sum()), float(q)))
        best = max(candidates)
        choose.loc[idx] = bool(test[feature].iloc[0] >= best[2])
        thresholds.append(best[2])
    return choose, thresholds


def conjunction_rule_lodo(data, features, quantiles=(0.25, 0.50, 0.75)):
    choose = pd.Series(False, index=data.index)
    thresholds = []
    for idx in data.index:
        train = data.loc[data.index != idx]
        test = data.loc[[idx]]
        best = None
        for q1 in np.quantile(train[features[0]], quantiles):
            for q2 in np.quantile(train[features[1]], quantiles):
                mask = (
                    (train[features[0]].to_numpy(float) >= q1)
                    & (train[features[1]].to_numpy(float) >= q2)
                )
                candidate = (selected_mean(train.gain_shared, mask), -int(mask.sum()), float(q1), float(q2))
                if best is None or candidate > best:
                    best = candidate
        use = bool(test[features[0]].iloc[0] >= best[2] and test[features[1]].iloc[0] >= best[3])
        choose.loc[idx] = use
        thresholds.append((best[2], best[3]))
    return choose, thresholds


def rank_score_rule_lodo(data, features, quantiles=(0.25, 0.50, 0.75)):
    choose = pd.Series(False, index=data.index)
    thresholds = []
    for idx in data.index:
        train = data.loc[data.index != idx].copy()
        test = data.loc[[idx]].copy()
        train_score = np.zeros(len(train))
        test_score = 0.0
        for feature in features:
            values = train[feature].to_numpy(float)
            train_score += train[feature].rank(pct=True).to_numpy()
            test_score += float(np.mean(values <= test[feature].iloc[0]))
        train_score /= len(features)
        test_score /= len(features)
        best = None
        for q in np.quantile(train_score, quantiles):
            mask = train_score >= q
            candidate = (selected_mean(train.gain_shared, mask), -int(mask.sum()), float(q))
            if best is None or candidate > best:
                best = candidate
        choose.loc[idx] = bool(test_score >= best[2])
        thresholds.append(best[2])
    return choose, thresholds


def evaluate_rules(data, prediction):
    gain = data.gain_shared.to_numpy(float)
    choices = {
        "always_shared": (pd.Series(False, index=data.index), []),
        "always_csm": (pd.Series(True, index=data.index), []),
    }
    for feature in ["deficit_lw_mean", "deficit_lw_sd_weighted", "subspace_heterogeneity_lw"]:
        choices[f"single_{feature}"] = single_rule_lodo(data, feature)
    choices["conjunction_deficit_H_ER"] = conjunction_rule_lodo(
        data, ["deficit_lw_mean", "deficit_lw_sd_weighted"]
    )
    choices["rank_score_deficit_H_subspace"] = rank_score_rule_lodo(
        data, ["deficit_lw_mean", "deficit_lw_sd_weighted", "subspace_heterogeneity_lw"]
    )
    choices["rank_score_H_only"] = rank_score_rule_lodo(data, ["deficit_lw_sd_weighted"])
    for model in ["M0_deficit_support_K", "M1_plus_H_ER", "M2_plus_subspace"]:
        for cutoff in (0.0, 0.5):
            choices[f"lodo_{model}_cutoff_{cutoff:.1f}"] = (prediction[model] > cutoff, [cutoff])
    rows = []
    thresholds = {}
    for name, (choose, used_thresholds) in choices.items():
        rows.append({"strategy": name, **classify_summary(gain, choose)})
        thresholds[name] = used_thresholds
    table = pd.DataFrame(rows).sort_values("mean_regret_pp")
    table.to_csv(OUT / "metric_selection_rule_results.csv", index=False)
    (OUT / "metric_selection_rule_thresholds.json").write_text(
        json.dumps(thresholds, indent=2), encoding="utf-8"
    )
    return table


def make_figures(data, rules):
    FIG.mkdir(parents=True, exist_ok=True)
    set_pr_style()
    from matplotlib.lines import Line2D

    iid = COLORS["LPEM"]
    shifted = COLORS["CRC"]
    active = data[data.active].sort_values("deficit_lw_sd_weighted").reset_index()
    active["key"] = np.arange(1, len(active) + 1)
    fig = plt.figure(figsize=(8.9, 5.9))
    ax = fig.add_axes([0.075, 0.13, 0.57, 0.81])
    colors = active.split.map({"iid": iid, "shifted": shifted})
    ax.scatter(active.deficit_lw_sd_weighted, active.gain_shared, c=colors, s=52, edgecolor="white", linewidth=0.55, zorder=3)
    for _, row in active.iterrows():
        ax.text(row.deficit_lw_sd_weighted, row.gain_shared, str(int(row.key)), color="white", fontsize=5.3, ha="center", va="center", fontweight="bold", zorder=4)
    ax.axhline(0, color="#333333", linewidth=0.8, zorder=2)
    ax.set_xlabel(r"Class-conditional effective-rank heterogeneity $H_{\mathrm{ER}}$")
    ax.set_ylabel("Accuracy advantage of class-specific metric (pp)")
    ax.set_ylim(-2.2, 2.8)
    ax.grid(color="#d9d9d9", linewidth=0.65)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    rho, pvalue = rho_p(active.deficit_lw_sd_weighted, active.gain_shared)
    ax.text(0.035, 0.965, rf"Spearman $\rho = {rho:+.2f}$, $p = {pvalue:.3f}$", transform=ax.transAxes, va="top", ha="left", fontsize=8, bbox={"facecolor": "white", "edgecolor": "none", "pad": 1.3})
    ax.legend(handles=[Line2D([0], [0], marker="o", color=iid, linestyle="none", markersize=4.5, label="i.i.d."), Line2D([0], [0], marker="o", color=shifted, linestyle="none", markersize=4.5, label="shifted")], loc="lower right", frameon=False)
    fig.add_artist(Line2D([0.665, 0.665], [0.11, 0.94], transform=fig.transFigure, color="#dddddd", linewidth=0.6))
    fig.text(0.69, 0.945, "Dataset key", fontsize=7.3, fontweight="bold", va="top")
    rows_per_column = 10
    ys = np.linspace(0.89, 0.15, rows_per_column)
    columns = [(0.695, 0.718), (0.836, 0.859)]
    for idx, row in active.iterrows():
        col = 0 if idx < rows_per_column else 1
        ridx = idx if col == 0 else idx - rows_per_column
        nx, tx = columns[col]
        color = iid if row.split == "iid" else shifted
        fig.text(nx, ys[ridx], str(int(row.key)), ha="center", va="center", color="white", fontsize=5.8, fontweight="bold", bbox={"boxstyle": "circle,pad=0.20", "facecolor": color, "edgecolor": "white", "linewidth": 0.35})
        fig.text(tx, ys[ridx], row.dataset.replace("_", " "), ha="left", va="center", fontsize=6.4)
    fig.savefig(FIG / "fig_metric_selection_heterogeneity.png", dpi=300, bbox_inches="tight", pad_inches=0.03)
    plt.close(fig)

    show = rules.sort_values("mean_regret_pp").head(10).copy()
    fig, ax = plt.subplots(figsize=(7.8, 4.8))
    ypos = np.arange(len(show))
    ax.barh(ypos, show.selected_mean_gain_pp, color=iid, alpha=0.90, zorder=3, label="Selected mean gain")
    ax.scatter(-show.mean_regret_pp, ypos, color=shifted, marker="D", s=24, zorder=4, label="Negative mean regret")
    ax.set_yticks(ypos, show.strategy.str.replace("_", " "))
    ax.invert_yaxis()
    ax.axvline(0, color="#333333", linewidth=0.8)
    ax.set_xlabel("Percentage points")
    ax.grid(axis="x", color="#d9d9d9", linewidth=0.65)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(frameon=False, loc="lower right")
    fig.tight_layout(pad=0.4)
    fig.savefig(FIG / "fig_metric_selection_rule_comparison.png", dpi=300, bbox_inches="tight", pad_inches=0.03)
    plt.close(fig)


def write_summary(data, correlations, regressions, rules):
    primary = correlations[
        correlations.subset.eq("active_20")
        & correlations.feature.eq("deficit_lw_sd_weighted")
        & correlations.target.eq("gain_shared")
    ].iloc[0]
    best = rules.iloc[0]
    active = data[data.active]
    summary = {
        "datasets": int(len(data)),
        "active_datasets": int(len(active)),
        "active_iid": int(active.split.eq("iid").sum()),
        "active_shifted": int(active.split.eq("shifted").sum()),
        "primary_feature": "deficit_lw_sd_weighted",
        "primary_target": "gain_shared",
        "primary_rho": float(primary.spearman_rho),
        "primary_p": float(primary.p_value),
        "primary_bootstrap_ci": [float(primary.bootstrap_ci_low), float(primary.bootstrap_ci_high)],
        "primary_loo_rho": [float(primary.loo_rho_low), float(primary.loo_rho_high)],
        "best_rule": str(best.strategy),
        "best_rule_selected_gain_pp": float(best.selected_mean_gain_pp),
        "best_rule_regret_pp": float(best.mean_regret_pp),
        "always_shared_gain_pp": float(rules.loc[rules.strategy.eq("always_shared"), "selected_mean_gain_pp"].iloc[0]),
        "always_csm_gain_pp": float(rules.loc[rules.strategy.eq("always_csm"), "selected_mean_gain_pp"].iloc[0]),
        "always_csm_regret_pp": float(rules.loc[rules.strategy.eq("always_csm"), "mean_regret_pp"].iloc[0]),
    }
    (OUT / "metric_selection_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    lines = [
        "# Metric-selection experiment",
        "",
        f"Datasets: {summary['datasets']} total; {summary['active_datasets']} active; {summary['active_iid']} i.i.d.; {summary['active_shifted']} shifted.",
        f"Primary correlation: rho={summary['primary_rho']:+.3f}, p={summary['primary_p']:.4f}, bootstrap CI {summary['primary_bootstrap_ci']}, LOO {summary['primary_loo_rho']}.",
        f"Best rule: {summary['best_rule']}, selected gain={summary['best_rule_selected_gain_pp']:+.3f} pp, regret={summary['best_rule_regret_pp']:.3f} pp.",
        f"Always shared={summary['always_shared_gain_pp']:+.3f} pp; always CSM={summary['always_csm_gain_pp']:+.3f} pp, regret={summary['always_csm_regret_pp']:.3f} pp.",
        "",
        "## Regressions",
        "",
        regressions.to_csv(index=False),
        "",
        "## Rules",
        "",
        rules.to_csv(index=False),
    ]
    (OUT / "metric_selection_report.md").write_text("\n".join(lines), encoding="utf-8")
    return summary


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    data, folds = build_dataset_table()
    correlations = build_correlations(data)
    build_fold_stability(folds, data)
    active = data[data.active].copy()
    regressions, prediction = fit_regressions(active)
    rules = evaluate_rules(active, prediction)
    make_figures(data, rules)
    summary = write_summary(data, correlations, regressions, rules)
    print(json.dumps(summary, indent=2))
    print(regressions.to_string(index=False))
    print(rules.to_string(index=False))


if __name__ == "__main__":
    main()
