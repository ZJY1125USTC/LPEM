# -*- coding: utf-8 -*-
"""Fold-wise class-geometry features for metric-selection analysis.

The independent unit is a dataset. Fold and seed results are cached here and
aggregated within each dataset by analyze_metric_selection.py. No test labels
or test-fold geometry enter these features.
"""
from __future__ import annotations

import argparse
import os
import sys
import time
import traceback
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.covariance import LedoitWolf
from sklearn.model_selection import train_test_split


CODE = Path(__file__).resolve().parents[1]
ROOT = CODE.parent
HARNESS = CODE / "harness"
OUT = ROOT / "results" / "metric_selection"
sys.path.insert(0, str(HARNESS))
os.chdir(HARNESS)

from data.preprocess import Preprocessor  # noqa: E402
from data.registry import load_config, load_dataset, select_specs  # noqa: E402
from data.splits import make_splits  # noqa: E402


ALL_DATASETS = [
    "wine",
    "iris",
    "seeds",
    "ecoli",
    "parkinsons",
    "heart_disease",
    "breast_cancer",
    "thyroid_disease",
    "dermatology",
    "mammographic_mass",
    "german_credit",
    "australian_credit",
    "bank_marketing",
    "vehicle",
    "segment",
    "vowel",
    "optical_digits",
    "adult",
    "spambase",
    "har",
    "pima",
    "credit_card_fraud",
    "lending_club",
    "home_credit",
    "occupancy_detection",
    "gas_sensor_drift",
]


def inner_split(y: np.ndarray, val_fraction: float = 0.2, seed: int = 0):
    idx = np.arange(len(y))
    if val_fraction <= 0 or len(idx) < 20:
        return idx, np.array([], dtype=int)
    counts = np.bincount(y)
    if counts[counts > 0].min() < 2:
        return idx, np.array([], dtype=int)
    sub_tr, sub_val = train_test_split(
        idx, test_size=val_fraction, stratify=y, random_state=seed, shuffle=True
    )
    return sub_tr, sub_val


def effective_rank(cov: np.ndarray) -> float:
    eig = np.clip(np.linalg.eigvalsh(cov), 1e-12, None)
    p = eig / eig.sum()
    return float(np.exp(-(p * np.log(p)).sum()))


def weighted_stats(values: np.ndarray, weights: np.ndarray) -> tuple[float, float, float]:
    values = np.asarray(values, float)
    weights = np.asarray(weights, float)
    weights = weights / weights.sum()
    mean = float(np.sum(weights * values))
    sd = float(np.sqrt(np.sum(weights * (values - mean) ** 2)))
    return mean, sd, float(np.std(values, ddof=0))


def class_geometry(
    Z: np.ndarray,
    y: np.ndarray,
    rank: int,
) -> dict[str, float]:
    covs_lw: list[np.ndarray] = []
    covs_emp: list[np.ndarray] = []
    means: list[np.ndarray] = []
    supports: list[float] = []
    classes: list[int] = []
    d = Z.shape[1]

    for cls in np.unique(y):
        Zc = Z[y == cls]
        n_k = len(Zc)
        if n_k < 2:
            continue
        center = Zc.mean(axis=0)
        emp = np.cov(Zc, rowvar=False, ddof=1)
        emp = np.atleast_2d(emp)
        try:
            lw = LedoitWolf(assume_centered=False).fit(Zc).covariance_
            lw = np.atleast_2d(lw)
        except Exception:
            lw = emp.copy()
        covs_lw.append(lw)
        covs_emp.append(emp)
        means.append(center)
        supports.append(float(n_k / max(1, rank * d)))
        classes.append(int(cls))

    base = {
        "d": float(d),
        "K": float(len(np.unique(y))),
        "K_cov_valid": float(len(covs_lw)),
        "n": float(len(y)),
    }
    if len(covs_lw) < 2:
        return base

    weights = np.asarray([np.sum(y == cls) for cls in classes], float)
    erank_lw = np.asarray([effective_rank(c) for c in covs_lw], float)
    erank_emp = np.asarray([effective_rank(c) for c in covs_emp], float)
    deficit_lw = 1.0 - erank_lw / d
    deficit_emp = 1.0 - erank_emp / d
    mean_lw, sd_lw, sd_unweighted_lw = weighted_stats(deficit_lw, weights)
    mean_emp, sd_emp, sd_unweighted_emp = weighted_stats(deficit_emp, weights)

    # Pairwise top-r subspace discrepancy. It is invariant to eigenvector sign
    # and rotation within a degenerate eigenspace.
    r = min(int(rank), d)
    subspaces = []
    for cov in covs_lw:
        eigvals, eigvecs = np.linalg.eigh(cov)
        order = np.argsort(eigvals)[::-1]
        subspaces.append(eigvecs[:, order[:r]])
    pair_values = []
    pair_weights = []
    for i in range(len(subspaces)):
        for j in range(i + 1, len(subspaces)):
            cross = subspaces[i].T @ subspaces[j]
            value = 1.0 - float(np.sum(cross * cross)) / r
            pair_values.append(max(0.0, min(1.0, value)))
            pair_weights.append(float(weights[i] * weights[j]))
    if pair_values:
        subspace_heterogeneity = float(
            np.average(pair_values, weights=np.asarray(pair_weights))
        )
    else:
        subspace_heterogeneity = float("nan")

    # Fisher ratio based on class means and pooled within-class scatter.
    wnorm = weights / weights.sum()
    global_mean = np.sum(np.stack(means) * wnorm[:, None], axis=0)
    sb = 0.0
    sw = 0.0
    for wk, mean, cov in zip(wnorm, means, covs_lw):
        delta = mean - global_mean
        sb += float(wk * np.dot(delta, delta))
        sw += float(wk * np.trace(cov))
    fisher_ratio = float(sb / max(sw, 1e-12))

    top1 = []
    logcond10 = []
    for cov in covs_lw:
        eig = np.clip(np.linalg.eigvalsh(cov), 1e-12, None)
        top1.append(float(eig[-1] / eig.sum()))
        q = max(1, int(np.ceil(0.10 * len(eig))))
        logcond10.append(float(np.log(eig[-1] / eig[q - 1])))

    base.update(
        {
            "erank_lw_mean": float(np.sum(wnorm * erank_lw)),
            "deficit_lw_mean": mean_lw,
            "deficit_lw_sd_weighted": sd_lw,
            "deficit_lw_sd_unweighted": sd_unweighted_lw,
            "deficit_emp_mean": mean_emp,
            "deficit_emp_sd_weighted": sd_emp,
            "deficit_emp_sd_unweighted": sd_unweighted_emp,
            "subspace_heterogeneity_lw": subspace_heterogeneity,
            "fisher_ratio_lw": fisher_ratio,
            "top1_lw_mean": float(np.mean(top1)),
            "logcond10_lw_mean": float(np.mean(logcond10)),
            "support_min": float(np.min(supports)),
            "support_median": float(np.median(supports)),
        }
    )
    return base


def dataset_fold_features(
    ds,
    spec: dict,
    seeds: list[int],
    rank: int,
) -> pd.DataFrame:
    X = ds.X
    y = np.asarray(ds.y)
    cat = list(getattr(ds, "categorical_cols", None) or [])
    strategy = spec.get("split") or "stratified_kfold"
    rows = []
    total = len(seeds) * 5
    done = 0
    for seed in seeds:
        splits = make_splits(
            y,
            groups=ds.groups,
            times=ds.times,
            strategy=strategy,
            n_splits=5,
            seed=seed,
        )
        for fold, (tr, _) in enumerate(splits):
            started = time.time()
            X_tr, y_tr = X.iloc[tr], y[tr]
            sub_tr, _ = inner_split(y_tr, 0.2, seed * 100 + fold)
            if len(sub_tr) < 30:
                sub_tr = np.arange(len(y_tr))
            pre = Preprocessor(categorical_cols=cat).fit(X_tr.iloc[sub_tr])
            Z = np.asarray(pre.transform(X_tr), float)
            row = class_geometry(Z, y_tr, rank=rank)
            row.update(
                {
                    "dataset": spec["name"],
                    "seed": seed,
                    "fold": fold,
                    "split_strategy": strategy,
                    "n_train": len(y_tr),
                    "seconds": time.time() - started,
                }
            )
            rows.append(row)
            done += 1
            print(
                f"[{spec['name']}] {done:02d}/{total:02d} seed={seed} fold={fold} "
                f"d={int(row['d'])} K={int(row['K'])} valid={int(row['K_cov_valid'])} "
                f"deficit={row.get('deficit_lw_mean', float('nan')):.3f} "
                f"H={row.get('deficit_lw_sd_weighted', float('nan')):.3f} "
                f"S={row.get('subspace_heterogeneity_lw', float('nan')):.3f}",
                flush=True,
            )
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--datasets", nargs="*", default=None)
    parser.add_argument("--seeds", nargs="*", type=int, default=[0, 1, 2, 3, 4])
    parser.add_argument("--rank", type=int, default=8)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    cache = OUT / "fold_cache"
    cache.mkdir(parents=True, exist_ok=True)
    cfg = load_config("datasets.yaml")
    names = args.datasets or ALL_DATASETS
    available = {s["name"]: s for s in select_specs(cfg, names=names)}
    failures = []

    for name in names:
        path = cache / f"{name}__r{args.rank}__folds.csv"
        if path.exists() and not args.overwrite:
            existing = pd.read_csv(path)
            expected = len(args.seeds) * 5
            if len(existing) == expected:
                print(f"[skip] {name}: cached {len(existing)} folds", flush=True)
                continue
        spec = available[name]
        try:
            print(f"[start] {name}", flush=True)
            ds = load_dataset(spec, root=cfg["root"])
            frame = dataset_fold_features(ds, spec, args.seeds, args.rank)
            frame.to_csv(path, index=False)
            print(f"[done] {name}: {path}", flush=True)
        except Exception as exc:
            failures.append(name)
            print(f"[fail] {name}: {type(exc).__name__}: {exc}", flush=True)
            traceback.print_exc()

    if failures:
        (OUT / "geometry_failures.txt").write_text("\n".join(failures), encoding="utf-8")
        raise SystemExit(f"failed datasets: {failures}")


if __name__ == "__main__":
    main()
