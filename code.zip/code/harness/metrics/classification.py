import numpy as np
from sklearn.metrics import accuracy_score, f1_score, log_loss

def accuracy(y, proba):
    return float(accuracy_score(y, proba.argmax(1)))

def macro_f1(y, proba):
    return float(f1_score(y, proba.argmax(1), average="macro"))

def nll(y, proba, eps=1e-12):
    proba = np.clip(proba, eps, 1.0)
    proba = proba / proba.sum(1, keepdims=True)
    return float(log_loss(y, proba, labels=np.arange(proba.shape[1])))

def brier(y, proba):
    onehot = np.zeros_like(proba); onehot[np.arange(len(y)), y] = 1.0
    return float(((proba - onehot) ** 2).sum(1).mean())
