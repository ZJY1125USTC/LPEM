import numpy as np

def _bins(conf, n_bins):
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    idx = np.clip(np.digitize(conf, edges[1:-1], right=True), 0, n_bins - 1)
    return idx

def ece(y, proba, n_bins=15):
    conf = proba.max(1)
    pred = proba.argmax(1)
    correct = (pred == y).astype(float)
    idx = _bins(conf, n_bins)
    total = len(y); val = 0.0
    for b in range(n_bins):
        m = idx == b
        if m.sum() == 0: continue
        val += m.sum() / total * abs(correct[m].mean() - conf[m].mean())
    return float(val)

def mce(y, proba, n_bins=15):
    conf = proba.max(1); pred = proba.argmax(1); correct = (pred == y).astype(float)
    idx = _bins(conf, n_bins); worst = 0.0
    for b in range(n_bins):
        m = idx == b
        if m.sum() == 0: continue
        worst = max(worst, abs(correct[m].mean() - conf[m].mean()))
    return float(worst)
