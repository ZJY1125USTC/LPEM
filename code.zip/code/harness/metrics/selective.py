import numpy as np

def risk_coverage_curve(y, proba, score=None):
    """Return (coverage, selective_risk) arrays, sorted by score descending."""
    if score is None:
        score = proba.max(1)
    pred = proba.argmax(1)
    err = (pred != y).astype(float)
    order = np.argsort(-score)
    err = err[order]
    n = len(err)
    cov = np.arange(1, n + 1) / n
    risk = np.cumsum(err) / np.arange(1, n + 1)
    return cov, risk

def aurc(y, proba, score=None):
    cov, risk = risk_coverage_curve(y, proba, score)
    return float(np.trapezoid(risk, cov))

def selective_risk_at_coverage(y, proba, coverage, score=None):
    cov, risk = risk_coverage_curve(y, proba, score)
    i = int(np.searchsorted(cov, coverage, side="left"))
    i = min(i, len(risk) - 1)
    return float(risk[i]), float(cov[i])

