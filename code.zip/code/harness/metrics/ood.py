import numpy as np
from sklearn.metrics import roc_auc_score

def auroc(id_score, ood_score):
    """Higher score = more in-distribution."""
    y = np.r_[np.ones(len(id_score)), np.zeros(len(ood_score))]
    s = np.r_[id_score, ood_score]
    return float(roc_auc_score(y, s))

def fpr_at_95_tpr(id_score, ood_score):
    y = np.r_[np.ones(len(id_score)), np.zeros(len(ood_score))]
    s = np.r_[id_score, ood_score]
    from sklearn.metrics import roc_curve
    fpr, tpr, _ = roc_curve(y, s)
    idx = np.searchsorted(tpr, 0.95)
    idx = min(idx, len(fpr) - 1)
    return float(fpr[idx])
