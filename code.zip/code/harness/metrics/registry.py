"""Metric direction registry.

Every ranking / statistical test must know whether larger or smaller is better.
"""

HIGHER_IS_BETTER = {"acc", "macro_f1", "balanced_acc", "auroc", "coverage", "cov80"}

LOWER_IS_BETTER = {"nll", "brier", "ece", "mce", "aurc", "selrisk80", "fpr95", "risk_gap"}

NOT_RANKED = {"seed", "fold"}

def higher_is_better(metric):
    if metric in HIGHER_IS_BETTER:
        return True
    if metric in LOWER_IS_BETTER:
        return False
    raise KeyError(
        f"Unknown metric {metric!r}. Add it to metrics/registry.py; "
        "silently guessing the direction is how results get inverted."
    )

def rank_metrics():
    return sorted(HIGHER_IS_BETTER | LOWER_IS_BETTER)
