from dataclasses import dataclass

@dataclass
class Config:
    # --- protocol ---
    n_splits: int = 5
    force_n_splits: bool = False   # programmatic override of datasets.yaml
    seeds: tuple = (0, 1, 2, 3, 4)
    val_fraction: float = 0.2
    refit_on_full: bool = True
    # --- imbalance ---
    smote: bool = False
    smote_k_neighbors: int = 5
    smote_majority_cap: int = 50_000   # strategy B: cap the majority class
    # --- leakage ---
    strict_leakage_checks: bool = True
    duplicate_check: bool = True
    duplicate_check_max_rows: int = 300_000
    duplicate_policy: str = "warn"       # warn | error
    duplicate_ratio_error: float = 0.01  # error only above this test-fold share
    duplicate_count_error: int = 5       # ...and only above this absolute count
    # --- io ---
    config_path: str = "datasets.yaml"
    data_root: str = "."
    results_dir: str = "results"
    pred_dir: str = "predictions"
    max_categorical_levels: int = 200
    random_state: int = 0
