# -*- coding: utf-8 -*-
"""Figure B4: metric-gain bar/scatter for all 26 ablation datasets."""
import os, pandas as pd, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pr_style as S

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results_ablation")
S.set_pr_style()

# read geometry csv for d values
g = os.path.join(HERE, "results_final", "geometry_gain_22.csv")
gdf = pd.read_csv(g)
dmap = dict(zip(gdf["dataset"], gdf["d"].astype(int)))

rows = []
for ds in sorted(dmap.keys()):
    p_full = os.path.join(RES, "%s__lpem_full.csv" % ds)
    p_fix = os.path.join(RES, "%s__lpem_fixed_metric.csv" % ds)
    if not (os.path.exists(p_full) and os.path.exists(p_fix)):
        continue
    full = pd.read_csv(p_full)
    fix = pd.read_csv(p_fix)
    rows.append((ds, int(dmap[ds]),
                 full.acc.mean()*100, fix.acc.mean()*100,
                 (full.acc.mean()-fix.acc.mean())*100))

df = pd.DataFrame(rows, columns=["dataset","d","acc_full","acc_fixed","delta_pp"])
df = df.sort_values("d")
print(df.to_string(index=False))
df.to_csv(os.path.join(HERE, "results_final", "fig_b4_data_26.csv"), index=False)

fig, ax = plt.subplots(figsize=(7.0, 3.8), dpi=300)
ax.axhline(0, color="black", lw=0.8)
ax.axvline(8, color="0.6", lw=0.8, ls="--")
x = df["d"].values; y = df["delta_pp"].values
colors = ["0.55" if d <= 8 else "#1f4e79" for d in x]
ax.scatter(x, y, s=34, c=colors, zorder=3)

# annotate: label the big gain + the zero-gain cluster + a few mid
label_set = {"har","spambase","optical_digits","vehicle","vowel",
             "australian_credit","segment","wine","pima","seeds",
             "credit_card_fraud","lending_club","home_credit"}
for _, r in df.iterrows():
    if r.dataset not in label_set:
        continue
    off = (3, 3)
    if r.dataset == "har": off = (-60, 4)
    if r.dataset == "spambase": off = (-55, 4)
    if r.dataset == "optical_digits": off = (-70, -10)
    if r.dataset == "vehicle": off = (4, -10)
    if r.dataset == "vowel": off = (4, 4)
    if r.dataset == "pima": off = (-30, -10)
    if r.dataset == "seeds": off = (-25, 4)
    if r.dataset == "credit_card_fraud": off = (4, 4)
    if r.dataset == "lending_club": off = (4, -10)
    if r.dataset == "home_credit": off = (-70, 4)
    ax.annotate(r.dataset.replace("_", " "), (r.d, r.delta_pp),
                textcoords="offset points", xytext=off, fontsize=6.5, color="0.15")

ax.set_xlabel("encoded dimension d", fontsize=8)
ax.set_ylabel("$\\Delta$ accuracy (pp): full $-$ frozen metric", fontsize=8)
ax.set_xscale("log")
ax.set_xticks([4, 8, 16, 32, 64, 128, 256, 512])
ax.set_xticklabels(["4","8","16","32","64","128","256","512"], fontsize=7.5)
ax.tick_params(axis="y", labelsize=7.5)
ax.text(8.6, ax.get_ylim()[1]*0.92, "r = d", fontsize=6.5, color="0.5")
ax.grid(alpha=0.25, lw=0.5)
for s in ("top","right"):
    ax.spines[s].set_visible(False)
fig.tight_layout()
out = os.path.join(HERE, "figures", "pr", "figB4_metric_gain.png")
fig.savefig(out, bbox_inches="tight")
print("saved", out)