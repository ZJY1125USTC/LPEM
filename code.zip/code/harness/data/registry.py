"""Dataset registry driven by datasets.yaml.

Every loader returns a Dataset whose features are still raw (a DataFrame).
Encoding, imputation and scaling happen inside the fold-wise Preprocessor.
"""
from __future__ import annotations
import glob
import os
import re
import numpy as np
import pandas as pd
from pandas.api.types import is_numeric_dtype, is_bool_dtype

from .schema import Dataset

BUILTIN = ("iris", "wine", "breast_cancer", "digits")


def load_config(path="datasets.yaml"):
    import yaml
    with open(path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    defaults = cfg.get("defaults", {}) or {}
    datasets = []
    for spec in cfg.get("datasets", []):
        merged = dict(defaults)
        merged.update(spec)
        datasets.append(merged)
    return {"root": cfg.get("root", "."), "defaults": defaults,
            "datasets": datasets}


def select_specs(config, names=None, groups=None):
    specs = config["datasets"]
    if names:
        wanted = set(names)
        specs = [s for s in specs if s["name"] in wanted]
        missing = wanted - {s["name"] for s in specs}
        if missing:
            raise KeyError(f"Unknown dataset(s): {sorted(missing)}")
    if groups:
        wanted_g = set(groups)
        specs = [s for s in specs if s.get("group") in wanted_g]
    return specs


def _resolve(path, root):
    if not path:
        raise ValueError("missing path")
    return path if os.path.isabs(path) else os.path.join(root, path)


def _load_builtin(name):
    from sklearn.datasets import (load_iris, load_wine,
                                  load_breast_cancer, load_digits)
    fn = {"iris": load_iris, "wine": load_wine,
          "breast_cancer": load_breast_cancer, "digits": load_digits}[name]
    d = fn()
    X = pd.DataFrame(np.asarray(d.data, dtype=np.float64),
                     columns=[str(c) for c in d.feature_names])
    return X, np.asarray(d.target, dtype=int), []


def _load_csv(path, sep=",", na_values=None, encoding="utf-8"):
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"{path} not found. Check the path in datasets.yaml.")
    return pd.read_csv(path, sep=sep, na_values=na_values, encoding=encoding,
                       low_memory=False)


def _load_openml(name, version=1):
    from sklearn.datasets import fetch_openml
    d = fetch_openml(name=name, version=version, as_frame=True, parser="auto")
    return d.data.copy(), d.target.copy()


def _load_npz(path, x_key="X", y_key="y"):
    if not os.path.exists(path):
        raise FileNotFoundError(f"{path} not found (cached features).")
    z = np.load(path, allow_pickle=True)
    X = pd.DataFrame(np.asarray(z[x_key], dtype=np.float64))
    X.columns = [f"f{i}" for i in range(X.shape[1])]
    return X, np.asarray(z[y_key]), []


def _load_whitespace(paths, sep=r"\s+"):
    """Headerless whitespace-separated files, label in the last column."""
    frames = [pd.read_csv(p, sep=sep, header=None, engine="python")
              for p in paths]
    df = pd.concat(frames, ignore_index=True)
    n = df.shape[1]
    df.columns = [f"f{i}" for i in range(n - 1)] + ["target"]
    return df


def _load_libsvm(paths, n_features=None, batch_from_name=True):
    """Sparse libsvm files, one file per drift batch.

    Returns a dense frame plus a `batch` column, so group_kfold cannot leak
    across batches.
    """
    max_idx = n_features or 0
    if max_idx == 0:
        for p in paths:
            with open(p, encoding="utf-8", errors="ignore") as f:
                for line in f:
                    for kv in line.split()[1:]:
                        max_idx = max(max_idx, int(kv.split(":")[0]))
    max_idx = max_idx or 128

    rows, labels, batches = [], [], []
    for p in paths:
        m = re.search(r"(\d+)", os.path.basename(p))
        batch = int(m.group(1)) if (batch_from_name and m) else 0
        with open(p, encoding="utf-8", errors="ignore") as f:
            for line in f:
                parts = line.split()
                if not parts:
                    continue
                vec = np.zeros(max_idx, dtype=np.float64)
                for kv in parts[1:]:
                    k, v = kv.split(":")
                    vec[int(k) - 1] = float(v)
                rows.append(vec)
                labels.append(parts[0])
                batches.append(batch)

    X = pd.DataFrame(np.vstack(rows), columns=[f"f{i+1}" for i in range(max_idx)])
    X["batch"] = batches
    return X, pd.Series(labels)


def _dedup_mask(X_feat, y_raw, policy="drop_group"):
    """Mask of rows to keep after removing exact duplicate feature vectors.

    `policy` controls rows whose duplicates disagree on the label:
      drop_group   remove every row in that duplicate group (default)
      keep_first   keep the first occurrence, ignore the conflict
    """
    h = pd.util.hash_pandas_object(X_feat, index=False).to_numpy()
    y = np.asarray(y_raw)
    frame = pd.DataFrame({"h": h, "y": y})
    nun = frame.groupby("h")["y"].nunique()
    conflicting = set(nun[nun > 1].index)

    keep = ~pd.Series(h).duplicated(keep="first").to_numpy()
    if policy == "drop_group" and conflicting:
        keep &= ~np.isin(h, list(conflicting))
    stats = {"duplicates": int((~keep).sum()),
             "conflicting_groups": len(conflicting)}
    return keep, stats


def _split_labels(y_raw):
    y, uniques = pd.factorize(pd.Series(y_raw), sort=True)
    return y.astype(int), [str(u) for u in uniques]


def _resolve_target(df, spec, name):
    target = spec.get("target_col", "last")
    if target in (None, "", "last"):
        target = df.columns[-1]
        print(f"[warn] {name}: target_col not set, using last column {target!r}")
    if target not in df.columns:
        raise KeyError(f"{name}: target_col {target!r} not in columns")
    return target


def load_dataset(spec, root="."):
    """Build a Dataset from one spec dict."""
    name = spec["name"]
    source = spec.get("source", "csv")
    categorical = list(spec.get("categorical_cols") or [])
    groups = None
    times = None

    if source == "builtin":
        X, y_raw, categorical = _load_builtin(name)

    elif source == "csv":
        df = _load_csv(_resolve(spec.get("path"), root),
                       sep=spec.get("sep", ","),
                       na_values=spec.get("na_values"))
        target = _resolve_target(df, spec, name)
        y_raw = df[target]
        X = df.drop(columns=[target])

    elif source == "whitespace":
        paths = spec.get("paths") or [spec.get("path")]
        paths = [_resolve(p, root) for p in paths]
        for p in paths:
            if not os.path.exists(p):
                raise FileNotFoundError(f"{name}: {p} not found")
        df = _load_whitespace(paths, sep=spec.get("sep_regex", r"\s+"))
        y_raw = df["target"]
        X = df.drop(columns=["target"])

    elif source == "libsvm":
        pattern = _resolve(spec.get("path"), root)
        paths = sorted(glob.glob(pattern))
        if not paths:
            raise FileNotFoundError(f"{name}: no files match {pattern}")
        X, y_raw = _load_libsvm(paths, spec.get("n_features"),
                                spec.get("batch_from_name", True))

    elif source == "openml":
        X, y_raw = _load_openml(spec["openml_name"],
                                spec.get("openml_version", 1))
        X = X.copy()

    elif source == "npz":
        X, y_raw, categorical = _load_npz(_resolve(spec.get("path"), root),
                                          spec.get("x_key", "X"),
                                          spec.get("y_key", "y"))

    else:
        raise ValueError(f"{name}: unknown source {source!r}")

    # exact-duplicate removal happens before group/time columns are extracted,
    # so every aligned array keeps the same row set
    if spec.get("deduplicate"):
        excluded = {spec.get("group_col"), spec.get("time_col")} | set(spec.get("drop_cols", []))
        feature_cols = [c for c in X.columns if c not in excluded]
        keep, stats = _dedup_mask(X[feature_cols], y_raw,
                                  spec.get("on_label_conflict", "drop_group"))
        X = X.loc[keep].reset_index(drop=True)
        y_raw = pd.Series(np.asarray(y_raw)[keep])
        print(f"[dedup] {name}: removed {stats['duplicates']} duplicate rows "
              f"({stats['conflicting_groups']} label-conflicting groups)")

    # metadata columns are never features
    if spec.get("group_col"):
        gc = spec["group_col"]
        if gc not in X.columns:
            raise KeyError(f"{name}: group_col {gc!r} not in columns")
        groups = X[gc].to_numpy()
        X = X.drop(columns=[gc])

    if spec.get("time_col"):
        tc = spec["time_col"]
        if tc not in X.columns:
            raise KeyError(f"{name}: time_col {tc!r} not in columns")
        times = pd.to_datetime(X[tc], errors="coerce", format="mixed").to_numpy()
        X = X.drop(columns=[tc])

    drop = [c for c in spec.get("drop_cols", []) if c in X.columns]
    X = X.drop(columns=drop)

    # categorical detection: explicit list wins, else non-numeric dtypes.
    # pandas >= 3.0 uses a dedicated `str` dtype, so match on semantics.
    detected = [c for c in X.columns
                if not is_numeric_dtype(X[c]) and not is_bool_dtype(X[c])]
    categorical = sorted(set(categorical) | set(detected))

    for c in X.columns:
        if c not in categorical:
            X[c] = pd.to_numeric(X[c], errors="coerce")

    suffix = spec.get("strip_label_suffix")
    if suffix:
        y_raw = (pd.Series(y_raw).astype(str).str.strip()
                 .str.rstrip(suffix))

    y, class_names = _split_labels(y_raw)
    X = X.reset_index(drop=True)

    return Dataset(
        name=name, X=X, y=y, categorical_cols=categorical,
        groups=groups, times=times, task=spec.get("task", "cls"),
        meta={"group": spec.get("group"), "class_names": class_names,
              "source": source, "split": spec.get("split"),
              "n_splits": spec.get("n_splits"), "smote": spec.get("smote")},
    )
