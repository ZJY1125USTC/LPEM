from __future__ import annotations
"""Dataset container. Features stay as a raw DataFrame until the fold-wise
preprocessor sees them, so categorical encoding cannot leak across folds."""
from dataclasses import dataclass, field
import numpy as np
import pandas as pd


@dataclass
class Dataset:
    name: str
    X: pd.DataFrame                 # raw features, mixed dtypes allowed
    y: np.ndarray                   # int labels in 0..C-1
    categorical_cols: list = field(default_factory=list)
    groups: np.ndarray | None = None
    times: np.ndarray | None = None
    task: str = "cls"
    meta: dict = field(default_factory=dict)

    @property
    def n_samples(self) -> int:
        return len(self.X)

    @property
    def n_features(self) -> int:
        return self.X.shape[1]

    @property
    def n_classes(self) -> int:
        return int(self.y.max()) + 1

    def subset(self, idx) -> "Dataset":
        return Dataset(
            name=self.name,
            X=self.X.iloc[idx].reset_index(drop=True),
            y=self.y[idx],
            categorical_cols=list(self.categorical_cols),
            groups=None if self.groups is None else self.groups[idx],
            times=None if self.times is None else self.times[idx],
            task=self.task,
            meta=dict(self.meta),
        )
