"""Splitting strategies.

stratified_kfold  default for i.i.d. tabular data
group_kfold       use when rows share a group (subject, patient, device)
time_series       use when rows are ordered in time (drift, occupancy, credit)
"""
from __future__ import annotations
import numpy as np
from sklearn.model_selection import (StratifiedKFold, GroupKFold,
                                     StratifiedGroupKFold, TimeSeriesSplit)


def make_splits(y, groups=None, times=None, strategy="stratified_kfold",
                n_splits=5, seed=0):
    n = len(y)
    if strategy == "stratified_kfold":
        skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        return list(skf.split(np.zeros(n), y))

    if strategy == "group_kfold":
        if groups is None:
            raise ValueError("group_kfold requires a group column")
        if len(np.unique(groups)) < n_splits:
            raise ValueError("fewer groups than folds")
        try:
            cv = StratifiedGroupKFold(n_splits=n_splits, shuffle=True,
                                      random_state=seed)
            return list(cv.split(np.zeros(n), y, groups))
        except TypeError:
            cv = GroupKFold(n_splits=n_splits)
            return list(cv.split(np.zeros(n), y, groups))

    if strategy == "time_series":
        if times is None:
            raise ValueError("time_series requires a time column")
        order = np.argsort(times, kind="mergesort")
        y_sorted = y[order]
        cv = TimeSeriesSplit(n_splits=n_splits)
        return [(order[tr], order[te]) for tr, te in cv.split(y_sorted)]

    raise ValueError(f"unknown split strategy {strategy!r}")


def apply_smote(X, y, k_neighbors=5, random_state=0, majority_cap=None):
    """Resample the training portion of an imbalanced dataset.

    Strategy B (used for credit_card_fraud):
      1. if the majority class exceeds `majority_cap`, subsample it to the cap;
      2. apply SMOTE until the minority class matches the majority.

    Both steps happen on the training portion only. The validation and test
    folds keep the original class distribution.
    """
    try:
        from imblearn.over_sampling import SMOTE
    except ImportError as e:
        raise ImportError("pip install imbalanced-learn") from e

    X = np.asarray(X)
    y = np.asarray(y)

    if majority_cap:
        counts = np.bincount(y)
        majority = int(counts.argmax())
        if counts[majority] > majority_cap:
            rng = np.random.default_rng(random_state)
            idx_maj = np.where(y == majority)[0]
            keep_maj = rng.choice(idx_maj, size=majority_cap, replace=False)
            idx_other = np.where(y != majority)[0]
            keep = np.concatenate([keep_maj, idx_other])
            keep.sort()
            X, y = X[keep], y[keep]

    return SMOTE(k_neighbors=k_neighbors,
                 random_state=random_state).fit_resample(X, y)
