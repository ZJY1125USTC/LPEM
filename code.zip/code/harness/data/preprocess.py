"""Fold-wise preprocessing: imputation, one-hot encoding, scaling.

Everything is fitted on the training portion only. Categorical levels are
learned from the training fold, so a category that appears only in the test
fold is ignored rather than silently creating a column (schema leakage).
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder


class Preprocessor:
    def __init__(self, categorical_cols=None, scale=True, min_frequency=None,
                 max_categorical_levels=200):
        self.categorical_cols = list(categorical_cols or [])
        self.scale = scale
        self.min_frequency = min_frequency
        self.max_categorical_levels = max_categorical_levels

    def fit(self, X: pd.DataFrame):
        if not isinstance(X, pd.DataFrame):
            raise TypeError("Preprocessor expects a pandas DataFrame")
        self.columns_ = list(X.columns)
        self.cat_cols_ = [c for c in self.columns_ if c in self.categorical_cols]
        self.num_cols_ = [c for c in self.columns_ if c not in self.cat_cols_]

        if self.num_cols_:
            self.num_imputer_ = SimpleImputer(strategy="median",
                                              keep_empty_features=True)
            self.scaler_ = StandardScaler() if self.scale else None
            num = X[self.num_cols_].astype(np.float64)
            num = num.replace([np.inf, -np.inf], np.nan)
            num = self.num_imputer_.fit_transform(num)
            if self.scaler_ is not None:
                self.scaler_.fit(num)

        if self.cat_cols_ and self.max_categorical_levels:
            too_wide = [(c, int(X[c].nunique(dropna=True)))
                        for c in self.cat_cols_
                        if X[c].nunique(dropna=True) > self.max_categorical_levels]
            if too_wide:
                detail = ", ".join(f"{c}={k}" for c, k in too_wide[:5])
                raise ValueError(
                    f"Categorical column(s) with more than "
                    f"{self.max_categorical_levels} levels: {detail}. "
                    f"Drop the column, or raise max_categorical_levels."
                )

        if self.cat_cols_:
            self.cat_imputer_ = SimpleImputer(strategy="most_frequent")
            self.encoder_ = OneHotEncoder(
                handle_unknown="ignore", sparse_output=False,
                min_frequency=self.min_frequency,
            )
            cat = X[self.cat_cols_].astype(object)
            cat = self.cat_imputer_.fit_transform(cat)
            self.encoder_.fit(cat)
            self.cat_feature_names_ = list(
                self.encoder_.get_feature_names_out(self.cat_cols_)
            )
        else:
            self.cat_feature_names_ = []
        return self

    def transform(self, X: pd.DataFrame) -> np.ndarray:
        if not isinstance(X, pd.DataFrame):
            raise TypeError("Preprocessor expects a pandas DataFrame")
        missing = [c for c in self.columns_ if c not in X.columns]
        extra = [c for c in X.columns if c not in self.columns_]
        if extra:
            raise KeyError(f"Unexpected columns at transform time: {extra[:5]}")
        if missing:
            X = X.copy()
            for c in missing:
                X[c] = np.nan
        X = X[self.columns_]

        blocks = []
        if self.num_cols_:
            num = X[self.num_cols_].astype(np.float64)
            num = num.replace([np.inf, -np.inf], np.nan)
            num = self.num_imputer_.transform(num)
            if self.scaler_ is not None:
                num = self.scaler_.transform(num)
            blocks.append(np.asarray(num, dtype=np.float64))
        if self.cat_cols_:
            cat = X[self.cat_cols_].astype(object)
            cat = self.cat_imputer_.transform(cat)
            blocks.append(np.asarray(self.encoder_.transform(cat), dtype=np.float64))
        if not blocks:
            return np.empty((len(X), 0), dtype=np.float64)
        return np.hstack(blocks)

    def fit_transform(self, X):
        return self.fit(X).transform(X)

    @property
    def feature_names_out_(self):
        return list(self.num_cols_) + list(self.cat_feature_names_)
