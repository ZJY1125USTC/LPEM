"""Leakage checks.

These are cheap structural checks, not a proof of correctness. They catch the
failure modes that actually occur in practice:

  * index overlap between train and test
  * group overlap (same subject / patient / device on both sides)
  * temporal overlap (training on the future)
  * identical feature rows on both sides (duplicates, near-duplicate records)
"""
from __future__ import annotations
import numpy as np
import pandas as pd


class LeakageError(AssertionError):
    pass


def row_hashes(X: pd.DataFrame) -> np.ndarray:
    return pd.util.hash_pandas_object(X, index=False).to_numpy()


def check_fold(name, X, tr, te, groups=None, times=None, hashes=None,
               fold_label="", dup_check=True, dup_policy="warn",
               dup_ratio_error=0.01, dup_count_error=5, warnings_out=None):
    """Raise LeakageError on the first violation; return a dict of findings."""
    report = {"dataset": name, "fold": fold_label}

    overlap = np.intersect1d(tr, te)
    if len(overlap):
        raise LeakageError(
            f"{name} {fold_label}: {len(overlap)} indices in both train and test"
        )

    if groups is not None:
        g_overlap = np.intersect1d(np.unique(groups[tr]), np.unique(groups[te]))
        if len(g_overlap):
            raise LeakageError(
                f"{name} {fold_label}: {len(g_overlap)} groups appear in both "
                f"train and test (use split: group_kfold)"
            )
        report["n_groups_train"] = int(len(np.unique(groups[tr])))
        report["n_groups_test"] = int(len(np.unique(groups[te])))

    if times is not None:
        tr_max = np.nanmax(times[tr].astype("datetime64[ns]").astype(np.int64))
        te_min = np.nanmin(times[te].astype("datetime64[ns]").astype(np.int64))
        if tr_max > te_min:
            raise LeakageError(
                f"{name} {fold_label}: training data extends beyond the first "
                f"test timestamp (use split: time_series)"
            )
        report["time_ordered"] = True

    if dup_check and hashes is not None:
        n_common = int(len(np.intersect1d(hashes[tr], hashes[te])))
        ratio = n_common / max(len(te), 1)
        report["duplicate_rows"] = n_common
        report["duplicate_ratio"] = ratio
        if n_common and (dup_policy == "error" or
                         (ratio > dup_ratio_error and n_common >= dup_count_error)):
            raise LeakageError(
                f"{name} {fold_label}: {n_common} identical feature rows in both "
                f"train and test ({ratio:.2%} of the test fold). Deduplicate the "
                f"data or switch to group_kfold."
            )
        if n_common and warnings_out is not None:
            warnings_out.append(
                f"{name} {fold_label}: {n_common} duplicate rows across the split "
                f"({ratio:.2%}); treated as a warning"
            )
    return report
