# -*- coding: utf-8 -*-
"""Redraw every manuscript figure in the Pattern-Recognition house style.

Outputs (work/harness/figures/pr):
  fig1_cd_acc.png            Figure 1   Nemenyi CD, accuracy
  fig2_reliability_iid.png   Figure 2   reliability, adult + segment
  fig3_risk_coverage.png     Figure 3   macro risk-coverage, 22 i.i.d.
  fig4_reliability_shift.png Figure 4   reliability, vowel + gas sensor drift
  figB1_cd_nll.png           Figure B1
  figB2_cd_aurc.png          Figure B2
  figB3_cd_selrisk.png       Figure B3
  figB4_metric_gain.png      Figure B4
  figB5_risk_per_dataset.png Figure B5
"""
import glob
import json
import os
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pr_style as S
from aggregate import friedman_and_cd

S.set_pr_style()
OUT = os.path.join(HERE, "figures", "pr")
os.makedirs(OUT, exist_ok=True)

NUM = json.load(open(os.path.join(HERE, "reports", "ch6", "numbers.json"),
                     encoding="utf-8"))
IID = list(NUM["iid"])
SHIFTED = list(NUM["shifted"])

PRED_DIRS = [os.path.join(HERE, d) for d in
             ("predictions_final", "predictions_knn")]
GRID = np.linspace(0.05, 1.0, 96)
NB = 15                 # reliability bins (same 15 bins used for the ECE column)
MIN_COUNT = 25          # do not plot a bin with fewer than this many points
RELIABILITY = ["adult", "segment", "vowel", "gas_sensor_drift"]
B5_DS = ["adult", "vowel", "optical_digits", "gas_sensor_drift"]

DISPLAY = {v: k for k, v in S.KEY.items()}
DISPLAY["selective"] = "SelectiveNet"

BAD_SHAPE = {"class_geometry_test.csv", "fig_b4_data.csv",
             "geometry_vs_gain.csv", "geometry_vs_gain_v2.csv"}


# ----------------------------------------------------------------- data ----
def index_predictions():
    table = {}
    for d in PRED_DIRS:
        for f in glob.glob(os.path.join(d, "*.npz")):
            table[os.path.basename(f)] = f
    return table


def iter_runs(table, dataset, key):
    for name, path in sorted(table.items()):
        parts = name[:-4].split("__")
        if len(parts) < 3 or parts[0] != dataset or parts[1] != key:
            continue
        d = np.load(path)
        proba, y = d["proba"], d["y_true"]
        yield proba.max(1), (proba.argmax(1) == y)


def scan(table):
    """One pass over all prediction files: reliability bins + risk curves."""
    rel, curves = {}, {}
    edges = np.linspace(0.0, 1.0, NB + 1)
    for ds in sorted(set(IID) | set(SHIFTED)):
        for name in S.ORDER:
            key = S.KEY[name]
            num = np.zeros(NB)
            den = np.zeros(NB)
            csum = np.zeros(NB)
            runs = []
            for conf, ok in iter_runs(table, ds, key):
                b = np.clip(np.digitize(conf, edges[1:-1], right=True), 0, NB - 1)
                num += np.bincount(b, weights=ok.astype(float), minlength=NB)
                csum += np.bincount(b, weights=conf, minlength=NB)
                den += np.bincount(b, minlength=NB)
                order = np.argsort(-conf, kind="stable")
                err = (~ok)[order].astype(float)
                cum = np.cumsum(err) / np.arange(1, len(err) + 1)
                pos = np.clip((GRID * len(cum)).astype(int) - 1, 0, len(cum) - 1)
                runs.append(cum[pos])
            if not runs:
                continue
            keep = den >= MIN_COUNT
            rel[(ds, key)] = (csum[keep] / den[keep], num[keep] / den[keep])
            curves[(ds, key)] = np.asarray(runs)
    return rel, curves


def results_frame():
    frames = []
    files = sorted(glob.glob(os.path.join(HERE, "results_final", "*.csv")))
    files += sorted(glob.glob(os.path.join(HERE, "results_knn", "*__wknn.csv")))
    for f in files:
        if os.path.basename(f) in BAD_SHAPE:
            continue
        d = pd.read_csv(f)
        if {"dataset", "method", "acc"} <= set(d.columns):
            frames.append(d)
    df = pd.concat(frames, ignore_index=True)
    return df[df.dataset.isin(IID)]


# ----------------------------------------------------------------- audit ----
def audit(fig, name):
    """Report data-text boxes that a data curve passes through."""
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    texts = [t for t in fig.findobj(matplotlib.text.Text)
             if t.get_gid() == "dt" and t.get_visible()]
    lines = [l for l in fig.findobj(Line2D) if l.get_gid() == "dl"]
    bad = 0
    for t in texts:
        bb = t.get_window_extent(r).expanded(1.03, 1.20)
        hit = False
        for l in lines:
            xy = l.get_transform().transform(l.get_xydata())
            for a, b in zip(xy[:-1], xy[1:]):
                for k in range(11):
                    p = a + (b - a) * k / 10.0
                    if bb.x0 <= p[0] <= bb.x1 and bb.y0 <= p[1] <= bb.y1:
                        hit = True
                        break
                if hit:
                    break
            if hit:
                break
        bad += int(hit)
    out = 0
    for t in texts:
        bb = t.get_window_extent(r)
        if bb.x0 < -1 or bb.x1 > fig.bbox.width + 1:
            out += 1
    print(f"  [audit] {name}: {len(texts)} data texts, {bad} text-on-curve, {out} outside figure")

# ------------------------------------------------------------ CD diagrams ---
def _rows(vals, gap, max_rows=8):
    last = [-1e9] * max_rows
    out = []
    for v in vals:
        placed = False
        for r in range(max_rows):
            if v - last[r] >= gap:
                out.append(r)
                last[r] = v
                placed = True
                break
        if not placed:
            out.append(max_rows - 1)
    return out


def _cliques(vals, cd):
    k = len(vals)
    spans = []
    for i in range(k):
        j = i
        while j + 1 < k and vals[j + 1] - vals[i] <= cd:
            j += 1
        if j > i:
            spans.append((i, j))
    maximal = [s for s in spans
               if not any(t[0] <= s[0] and t[1] >= s[1] and t != s for t in spans)]
    return sorted(set(maximal))


def plot_cd(path, res, metric_label, note=None):
    ranks = res["mean_ranks"]
    cd = res["cd"]
    items = sorted(ranks.items(), key=lambda kv: kv[1])
    names = [DISPLAY.get(k, k) for k, _ in items]
    vals = np.array([v for _, v in items])
    k = len(vals)
    p = res["p_value"]

    xmin, xmax = float(vals.min()), float(vals.max())
    pad = max(0.44, 0.12 * (xmax - xmin))
    lo, hi = xmin - pad, xmax + pad
    if hi - lo < cd + 0.30:
        hi = lo + cd + 0.30

    fig_w = 5.85
    inner = fig_w - 0.12
    unit_in = 1.55
    axis_y = 0.0
    axis_label_y = -0.155
    ruler_y = -0.290
    ruler_text_y = -0.320
    bar0 = -0.470
    bar_dy = 0.118

    groups = _cliques(vals, cd)
    gap_scale = 1.0
    for attempt in range(8):
        texts = []
        # estimate label width in data units
        widths = [len(n) * 0.52 * 8.5 + 6 for n in names]
        gap = max(widths) / 72.0 / inner * (hi - lo) * 1.02 * gap_scale
        row = _rows(vals, gap)
        n_rows = max(row) + 1
        top = 0.105 + (n_rows - 1) * 0.118 + 0.105
        bottom = bar0 - bar_dy * (len(groups) - 1) - 0.105
        fig_h = (top - bottom) * unit_in + 0.30

        fig, ax = plt.subplots(figsize=(fig_w, fig_h))
        ax.set_xlim(lo, hi)
        ax.set_ylim(bottom, top)
        ax.axis("off")

        ax.hlines(axis_y, lo, hi, color="black", lw=0.9, zorder=1)
        for t in range(int(np.ceil(lo)), int(np.floor(hi)) + 1):
            ax.vlines(t, -0.020, 0.020, color="black", lw=0.9, zorder=1)
            ax.text(t, -0.040, str(t), ha="center", va="top", fontsize=8)

        w_units = [wp / 72.0 / inner * (hi - lo) for wp in widths]
        for i, ((n, v), r) in enumerate(zip(zip(names, vals), row)):
            y = 0.105 + r * 0.118
            y_end = y - 0.030
            for j in range(len(vals)):
                if row[j] < r and abs(v - vals[j]) < 0.5 * (w_units[i] + w_units[j]):
                    y_end = min(y_end, 0.105 + row[j] * 0.118 - 0.032)
            if y_end > 0.048:
                ax.plot([v, v], [0.032, y_end], color="0.62", lw=0.55, zorder=1)
            ax.plot([v], [0.0], marker="o", ms=3.6, color=S.COLORS[n],
                    markeredgecolor="white", markeredgewidth=0.4, zorder=4)
            texts.append(ax.text(v, y, f"{n} {v:.2f}", ha="center", va="bottom",
                                 fontsize=8.5, zorder=5, gid="dt"))

        ax.text((lo + hi) / 2, axis_label_y, "Average rank (1 = best)",
                ha="center", va="top", fontsize=8.5)

        x0 = lo + 0.04
        ax.plot([x0, x0 + cd], [ruler_y, ruler_y], color="black", lw=1.0)
        for x in (x0, x0 + cd):
            ax.plot([x, x], [ruler_y - 0.022, ruler_y + 0.022], color="black", lw=1.0)
        ax.text(x0 + cd / 2, ruler_text_y, f"CD = {cd:.2f}",
                ha="center", va="top", fontsize=8)

        for gi, (i, j) in enumerate(groups):
            y = bar0 - gi * bar_dy
            ax.plot([vals[i], vals[j]], [y, y], color="#37474f", lw=3.2,
                    solid_capstyle="butt", zorder=2)
            for x in (vals[i], vals[j]):
                ax.plot([x, x], [y - 0.026, y + 0.026], color="#37474f", lw=0.9)

        title = metric_label
        ax.set_title(title, fontsize=9.5, loc="left", pad=5)

        fig.canvas.draw()
        renderer = fig.canvas.get_renderer()
        boxes = [(r, t.get_window_extent(renderer)) for (_, r), t in zip(
            zip(names, row), texts)]
        clash = False
        for a in range(len(boxes)):
            for b in range(a + 1, len(boxes)):
                if boxes[a][0] != boxes[b][0]:
                    continue
                ba, bb = boxes[a][1], boxes[b][1]
                if ba.x0 < bb.x1 - 0.5 and bb.x0 < ba.x1 - 0.5:
                    clash = True
        if not clash or attempt == 7:
            break
        plt.close(fig)
        gap_scale *= 1.18

    audit(fig, os.path.basename(path))
    fig.savefig(path, dpi=300)
    plt.close(fig)
    print("wrote", os.path.basename(path), "rows", n_rows, "groups", len(groups))


# ------------------------------------------------------------- reliability ---
def reliability_figure(path, datasets, titles):
    n = len(datasets)
    fig, axes = plt.subplots(1, n, figsize=(5.85, 3.42))
    for ax, ds, title in zip(np.atleast_1d(axes), datasets, titles):
        ax.plot([0, 1], [0, 1], color="#9e9e9e", lw=0.9,
                ls=(0, (4.5, 3.0)), zorder=0)
        for name in S.ORDER:
            xs, ys = rel[(ds, S.KEY[name])]
            st = S.style_of(name)
            ax.plot(xs, ys, color=st["color"], ls=st["ls"], lw=st["lw"],
                    marker=st["marker"], ms=max(2.4, st["ms"] - 0.5),
                    markeredgewidth=0.55, markevery=1,
                    zorder=4 if name == "LPEM" else 3, clip_on=True, gid="dl")
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xticks(np.arange(0, 1.01, 0.25))
        ax.set_yticks(np.arange(0, 1.01, 0.25))
        ax.set_xlabel("Predicted confidence", labelpad=3)
        ax.set_ylabel("Empirical accuracy", labelpad=3)
        ax.grid(True, color="0.92", lw=0.5)
        ax.set_axisbelow(True)
        ax.set_title(title, fontsize=9, pad=5)
        ax.set_aspect("equal", adjustable="box")
    fig.legend(handles=S.legend_handles(), loc="lower center", ncol=4,
               frameon=False, handlelength=2.1, columnspacing=1.3,
               handletextpad=0.5, borderaxespad=0.0)
    fig.tight_layout(rect=(0, 0.10, 1, 1), w_pad=1.4)
    audit(fig, os.path.basename(path))
    fig.savefig(path, dpi=300)
    plt.close(fig)
    print("wrote", os.path.basename(path))


# ------------------------------------------------------------ risk-coverage --
def macro_curve(datasets, key):
    per_ds = [curves[(d, key)].mean(0) for d in datasets if (d, key) in curves]
    return np.mean(per_ds, axis=0)


def risk_coverage_figure(path, datasets, title):
    fig, ax = plt.subplots(figsize=(5.60, 3.30))
    ymax = 0.0
    for name in S.ORDER:
        ys = macro_curve(datasets, S.KEY[name])
        ymax = max(ymax, float(np.max(ys)))
        st = S.style_of(name)
        ax.plot(GRID, ys, color=st["color"], ls=st["ls"], lw=st["lw"],
                marker=st["marker"], ms=2.6, markevery=9,
                markeredgewidth=0.5, zorder=4 if name == "LPEM" else 3, gid="dl")
    ax.set_xlim(GRID[0], 1.0)
    ax.set_ylim(0, ymax * 1.14)
    ax.set_xlabel("Coverage", labelpad=3)
    ax.set_ylabel("Selective risk (error rate)", labelpad=3)
    ax.grid(True, color="0.92", lw=0.5)
    ax.set_axisbelow(True)
    ax.axvline(0.8, color="0.45", lw=0.9, ls=(0, (2, 2)), zorder=1)
    ax.annotate("80% coverage", xy=(0.8, 1.0),
                xycoords=("data", "axes fraction"), xytext=(-3, 2),
                textcoords="offset points", ha="right", va="bottom",
                fontsize=7.5, color="0.35", gid="dt")
    ax.set_title(title, fontsize=9.5, pad=5, loc="left")
    fig.legend(handles=S.legend_handles(), loc="lower center", ncol=4,
               frameon=False, handlelength=2.1, columnspacing=1.3,
               handletextpad=0.5, borderaxespad=0.0)
    fig.tight_layout(rect=(0, 0.115, 1, 1))
    audit(fig, os.path.basename(path))
    fig.savefig(path, dpi=300)
    plt.close(fig)
    print("wrote", os.path.basename(path))


def risk_per_dataset(path, datasets):
    fig, axes = plt.subplots(2, 2, figsize=(6.10, 4.65))
    for ax, ds in zip(axes.ravel(), datasets):
        top = 0.0
        for name in S.ORDER:
            key = S.KEY[name]
            if (ds, key) not in curves:
                continue
            ys = curves[(ds, key)].mean(0)
            top = max(top, float(np.max(ys)))
            st = S.style_of(name)
            ax.plot(GRID, ys, color=st["color"], ls=st["ls"], lw=st["lw"],
                    marker=st["marker"], ms=2.2, markevery=12,
                    markeredgewidth=0.45, zorder=4 if name == "LPEM" else 3, gid="dl")
        ax.set_xlim(GRID[0], 1.0)
        ax.set_ylim(0, top * 1.18)
        ax.grid(True, color="0.92", lw=0.5)
        ax.set_axisbelow(True)
        ax.set_title(ds.replace("_", " "), fontsize=8.6, pad=4)
        ax.tick_params(labelsize=7.5)
    for ax in axes[1]:
        ax.set_xlabel("Coverage", labelpad=2)
    for ax in axes[:, 0]:
        ax.set_ylabel("Selective risk", labelpad=2)
    fig.legend(handles=S.legend_handles(), loc="lower center", ncol=4,
               frameon=False, handlelength=2.0, columnspacing=1.2,
               handletextpad=0.45, borderaxespad=0.0)
    fig.tight_layout(rect=(0, 0.085, 1, 1), w_pad=1.2, h_pad=1.2)
    audit(fig, os.path.basename(path))
    fig.savefig(path, dpi=300)
    plt.close(fig)
    print("wrote", os.path.basename(path))


# ------------------------------------------------------- B4 metric gain ------
def metric_gain_figure(path):
    df = pd.read_csv(os.path.join(HERE, "results_final", "fig_b4_data.csv"))
    df = df.sort_values("d").reset_index(drop=True)

    fig, ax = plt.subplots(figsize=(5.70, 3.30))
    ax.axhline(0, color="0.25", lw=0.8, zorder=1)
    ax.axvline(8, color="0.55", lw=0.9, ls=(0, (4, 3)), zorder=1)

    inert = df["d"] <= 8
    ax.scatter(df.loc[inert, "d"], df.loc[inert, "delta_pp"], s=30,
               facecolor="0.78", edgecolor="0.35", linewidth=0.6,
               zorder=3, label="d $\\leq$ r (frame inert)")
    ax.scatter(df.loc[~inert, "d"], df.loc[~inert, "delta_pp"], s=34,
               facecolor=S.COLORS["LPEM"], edgecolor="white", linewidth=0.5,
               zorder=4, label="d > r")

    ax.set_xscale("log")
    ax.set_xticks([4, 8, 16, 32, 64, 128])
    ax.set_xticklabels(["4", "8", "16", "32", "64", "128"])
    ax.minorticks_off()
    ax.set_xlim(3.4, 190)
    ax.set_xlabel("Encoded dimension  d", labelpad=3)
    ax.set_ylabel("$\\Delta$ accuracy (pp):  full $-$ frozen metric", labelpad=3)
    ax.grid(True, color="0.92", lw=0.5)
    ax.set_axisbelow(True)
    ax.text(8.4, ax.get_ylim()[1] * 0.96, "d = r = 8", fontsize=7.2,
            color="0.4", ha="left", va="top", gid="dt")

    edge = ax.get_ylim()
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    dpi = fig.dpi
    s = dpi / 72.0

    cand = [(6, 5), (6, -11), (-6, 5), (-6, -11), (9, 0), (-9, 0),
            (0, 9), (0, -13), (12, 8), (-12, 8), (12, -12), (-12, -12)]
    placed = []
    ax_bb = ax.get_window_extent(renderer)
    pts = []
    for _, r in df.iterrows():
        qx, qy = ax.transData.transform((r.d, r.delta_pp))
        pts.append((qx - 5, qy - 5, qx + 5, qy + 5))

    # pre-measure each label
    sizes = []
    for _, r in df.iterrows():
        txt = ax.text(0, 0, r.dataset.replace("_", " "), fontsize=7.2)
        fig.canvas.draw()
        bb = txt.get_window_extent(renderer)
        sizes.append((bb.width, bb.height))
        txt.remove()

    for (_, r), (tw, th) in zip(df.iterrows(), sizes):
        px, py = ax.transData.transform((r.d, r.delta_pp))
        best = None
        for dx, dy in cand:
            x0 = px + dx * s
            y0 = py + dy * s
            box = (x0, y0, x0 + tw, y0 + th)
            if box[0] < ax_bb.x0 + 1 or box[2] > ax_bb.x1 - 1:
                continue
            if box[1] < ax_bb.y0 + 1 or box[3] > ax_bb.y1 - 1:
                continue
            hit = False
            for b in list(placed) + pts:
                if not (box[2] < b[0] - 2 or b[2] < box[0] - 2 or
                        box[3] < b[1] - 2 or b[3] < box[1] - 2):
                    hit = True
                    break
            if hit:
                continue
            best = (dx, dy, box)
            break
        if best is None:
            dx, dy = 6, 6
            best = (dx, dy, (px + dx * s, py + dy * s,
                             px + dx * s + tw, py + dy * s + th))
        placed.append(best[2])
        ax.annotate(r.dataset.replace("_", " "), (r.d, r.delta_pp),
                    textcoords="offset points", xytext=(best[0], best[1]),
                    fontsize=7.2, color="0.15",
                    ha="left", va="bottom", zorder=6, gid="dt")

    ax.legend(loc="lower right", frameon=False, fontsize=7.6, handletextpad=0.4,
              borderaxespad=0.3)
    audit(fig, os.path.basename(path))
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)
    print("wrote", os.path.basename(path))


# ------------------------------------------------------------------ main ----
if __name__ == "__main__":
    table = index_predictions()
    rel, curves = scan(table)

    df = results_frame()
    print("rows", len(df), "datasets", df.dataset.nunique(),
          "methods", sorted(df.method.unique()))

    specs = [("fig1_cd_acc.png", "acc", "Accuracy"),
             ("figB1_cd_nll.png", "nll", "Negative log-likelihood"),
             ("figB2_cd_aurc.png", "aurc", "AURC"),
             ("figB3_cd_selrisk.png", "selrisk80", "Selective risk at 80% coverage")]
    for fname, metric, label in specs:
        res = friedman_and_cd(df, metric)
        plot_cd(os.path.join(OUT, fname), res, label)

    reliability_figure(os.path.join(OUT, "fig2_reliability_iid.png"),
                       ["adult", "segment"],
                       ["Adult", "Segment"])
    reliability_figure(os.path.join(OUT, "fig4_reliability_shift.png"),
                       ["vowel", "gas_sensor_drift"],
                       ["vowel  (speaker-disjoint, K = 11)",
                        "gas sensor drift  (batch-disjoint, K = 6)"])

    risk_coverage_figure(os.path.join(OUT, "fig3_risk_coverage.png"), IID,
                         "Risk-coverage, macro-averaged over 22 i.i.d. datasets")
    risk_per_dataset(os.path.join(OUT, "figB5_risk_per_dataset.png"), B5_DS)
    metric_gain_figure(os.path.join(OUT, "figB4_metric_gain.png"))
    print("done ->", OUT)
