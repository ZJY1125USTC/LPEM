"""Unified method interface.

Contract
--------
fit(X_train, y_train, X_val, y_val)  -> self
    Train on (X_train, y_train). If X_val is not None, use it for early
    stopping or hyperparameter selection, never for gradient updates.
refit(X_train, y_train)              -> self
    Refit on the full training fold after the epoch count / hyperparameters
    have been chosen on the inner validation split.
predict_proba(X)                     -> (n, C)
    Columns must follow self.classes_ (set in fit).
predict_evidence(X)                  -> (n,)
    Higher means more in-distribution. Used for OOD and selective scoring.
"""
import numpy as np

class BaseMethod:
    name = "base"

    def fit(self, X_train, y_train, X_val=None, y_val=None):
        raise NotImplementedError

    def refit(self, X_train, y_train):
        """Default: refit with the same configuration, ignoring validation."""
        return self.fit(X_train, y_train, None, None)

    def predict_proba(self, X):
        raise NotImplementedError

    def predict_evidence(self, X):
        return self.predict_proba(X).max(axis=1)

    def predict(self, X):
        return self.predict_proba(X).argmax(axis=1)
