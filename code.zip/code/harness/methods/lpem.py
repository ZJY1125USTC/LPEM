"""LPEM: Learnable Prototype Evidence Machine.

Implements Sections 3 and 5 of the manuscript with the confirmed defaults:

  kernel        Gaussian, log phi = -d^2 / (2 tau_k^2), tau_k learnable
  mode weights  learnable, w = softmax(a), initialised from cluster masses
  metric        per-class low-rank L_k, rows orthonormal by construction (QR)
  class prior   empirical frequency, fixed
  optimiser     Adam, lr 1e-3, 200 epochs, early stopping on validation NLL
  regularisers  R_sep (hinge), R_sm (Gaussian curvature = 1/tau^2), R_ent

Temperature scaling is available as an optional post-hoc step but is OFF by
default: the ablation shows it is neutral on i.i.d. data (the evidence
construction is already calibrated) and harmful under domain shift.


R_met is inactive by construction: L_k is parameterised through a QR
factorisation, so L_k L_k^T = I_r for every parameter value.
"""
from __future__ import annotations

import copy
import numpy as np
import torch
import torch.nn.functional as F
from scipy.spatial.distance import cdist as scipy_cdist
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

from .base import BaseMethod


class LPEM(BaseMethod):
    name = "lpem"

    def __init__(self, n_k=3, rank=32, lr=1e-3, epochs=200, batch_size=8192,
                 patience=20, lambda_sep=1e-2, lambda_sm=1e-3,
                 lambda_ent=1e-3, delta_ratio=0.5, metric_init="pca_whiten",
                 temperature=False, learn_metric=True, evidence="gaussian",
                 share_metric=False, share_tau=False, seed=0, device=None,
                 verbose=False):
        self.n_k = n_k                      # int or {class: n_k}
        self.rank = rank
        self.lr = lr
        self.epochs = epochs
        self.batch_size = batch_size
        self.patience = patience
        self.lambda_sep = lambda_sep
        self.lambda_sm = lambda_sm
        self.lambda_ent = lambda_ent
        self.delta_ratio = delta_ratio
        self.metric_init = metric_init
        self.temperature = temperature
        # Ablation switch: False freezes L_k at the identity projection, i.e.
        # Euclidean distance on the standardised features.
        self.learn_metric = learn_metric
        # Ablation switch: True collapses the K class-specific frames to a
        # single rank-r frame shared by every class.
        self.share_metric = share_metric
        # Ablation switch for the theory: True forces a single bandwidth
        # shared by every class, so Z_k is class-independent and the head is
        # exactly the posterior of a mixture density with the fixed priors.
        self.share_tau = share_tau
        self.evidence = evidence
        self.temperature_ = 1.0
        self.seed = seed
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.verbose = verbose

    # ------------------------------------------------------------------ fit
    def fit(self, X_train, y_train, X_val=None, y_val=None):
        return self._fit(X_train, y_train, X_val, y_val, self.epochs)

    def refit(self, X_train, y_train):
        """Refit on the full training fold with the epoch count chosen on the
        inner validation split."""
        epochs = int(getattr(self, "best_epochs_", self.epochs))
        return self._fit(X_train, y_train, None, None, max(1, epochs))

    # --------------------------------------------------------------- helpers
    def _n_for(self, label):
        if isinstance(self.n_k, dict):
            return int(self.n_k.get(int(label), 3))
        return int(self.n_k)

    @staticmethod
    def _orthonormalize(L):
        q, _ = np.linalg.qr(L.T)
        return q.T.astype(np.float32)

    def _init_metric(self, Xk, r, d):
        if self.metric_init == "identity":
            L = np.zeros((r, d), dtype=np.float32)
            k = min(r, d)
            L[np.arange(k), np.arange(k)] = 1.0
            if r > k:
                rng = np.random.default_rng(self.seed)
                L[k:] = rng.normal(size=(r - k, d))
            return self._orthonormalize(L)

        # A class with a single sample, or with constant features, makes PCA
        # divide by zero. Fall back to random directions in that case.
        r_eff = int(min(r, max(0, Xk.shape[0] - 1), d))
        L = np.zeros((r, d), dtype=np.float32)
        if r_eff > 0 and np.isfinite(Xk).all() and Xk.std(axis=0).max() > 0:
            pca = PCA(n_components=r_eff, svd_solver="randomized",
                      random_state=self.seed)
            pca.fit(Xk)
            comps = np.nan_to_num(pca.components_, nan=0.0, posinf=0.0,
                                  neginf=0.0)
            ev = np.nan_to_num(pca.explained_variance_, nan=0.0, posinf=0.0,
                               neginf=0.0)
            scale = 1.0 / np.sqrt(np.maximum(ev, 1e-8))
            scale = np.where(np.isfinite(scale), scale, 1.0)
            L[:r_eff] = comps * scale[:, None]
        else:
            r_eff = 0
        if r_eff < r:
            rng = np.random.default_rng(self.seed + 1)
            L[r_eff:] = rng.normal(size=(r - r_eff, d))

        L = np.nan_to_num(L, nan=0.0, posinf=0.0, neginf=0.0)
        out = self._orthonormalize(L)
        if not np.isfinite(out).all():
            out = self._orthonormalize(
                np.random.default_rng(self.seed + 2).normal(size=(r, d))
            )
        return out

    # ------------------------------------------------------------------ fit
    def _fit(self, X_train, y_train, X_val, y_val, max_epochs):
        torch.manual_seed(self.seed)
        np.random.seed(self.seed)
        rng = np.random.default_rng(self.seed)

        X = np.asarray(X_train, dtype=np.float32)
        y = np.asarray(y_train, dtype=np.int64)
        n, d = X.shape
        self.classes_ = np.unique(y)
        # Cross-entropy requires contiguous targets; OOD leave-class protocols
        # and any subset of a dataset can hand us non-contiguous labels.
        y_idx = np.searchsorted(self.classes_, y)
        K = len(self.classes_)
        r = int(max(1, min(self.rank, d)))

        n_k_list = []
        n_max = max(1, max(self._n_for(c) for c in self.classes_))
        C0 = np.zeros((K, n_max, d), dtype=np.float32)
        logw0 = np.full((K, n_max), -1e9, dtype=np.float32)
        tau0 = np.ones(K, dtype=np.float32)
        L0 = np.zeros((K, r, d), dtype=np.float32)
        delta = np.zeros(K, dtype=np.float32)

        for ki, label in enumerate(self.classes_):
            Xk = X[y == label]
            n_cls = len(Xk)
            nk = int(min(self._n_for(label), max(1, n_cls // 2)))
            n_k_list.append(nk)

            if nk <= 1 or n_cls < 4:
                centers = Xk.mean(axis=0, keepdims=True)
                counts = np.array([n_cls], dtype=float)
            else:
                km = KMeans(n_clusters=nk, n_init=5, random_state=self.seed)
                km.fit(Xk)
                centers = km.cluster_centers_.astype(np.float32)
                counts = np.bincount(km.labels_, minlength=nk).astype(float)

            C0[ki, :nk] = centers
            w = counts / max(counts.sum(), 1.0)
            lw = np.log(np.maximum(w, 1e-12))
            lw -= lw.mean()
            logw0[ki, :nk] = lw

            Lk = self._init_metric(Xk, r, d)
            L0[ki] = Lk

            m = min(n_cls, 5000)
            sub = Xk[rng.choice(n_cls, size=m, replace=False)]
            dz = scipy_cdist(sub @ Lk.T, centers @ Lk.T)
            tau_est = float(np.median(dz.min(axis=1)))
            tau0[ki] = tau_est if np.isfinite(tau_est) and tau_est > 0 else 1.0

            if nk > 1:
                pair = scipy_cdist(centers, centers)
                np.fill_diagonal(pair, np.inf)
                delta[ki] = float(self.delta_ratio * np.median(pair.min(axis=1)))

        self.n_k_eff = n_k_list
        pi = np.bincount(y_idx, minlength=K).astype(np.float32)
        pi /= pi.sum()

        dev = self.device
        self.A = torch.tensor(L0, device=dev, requires_grad=self.learn_metric)
        self.C = torch.tensor(C0, device=dev, requires_grad=True)
        self.logit_w = torch.tensor(logw0, device=dev, requires_grad=True)
        if self.share_tau:
            tau_init = np.full(1, float(np.mean(tau0)), dtype=np.float32)
        else:
            tau_init = tau0
        self.log_tau = torch.tensor(np.log(np.maximum(tau_init, 1e-2)),
                                    device=dev, requires_grad=True)
        self.pi = torch.tensor(pi, device=dev)
        self.delta = torch.tensor(delta, device=dev)

        self.K_ = K
        self.r_ = r
        self.n_max_ = n_max
        self.best_epochs_ = max_epochs

        params = [self.A, self.C, self.logit_w, self.log_tau]
        opt = torch.optim.Adam(params, lr=self.lr)

        Xt = torch.tensor(X, device=dev)
        yt = torch.tensor(y_idx, device=dev)
        Xv = torch.tensor(np.asarray(X_val, dtype=np.float32), device=dev) \
            if X_val is not None and len(X_val) else None
        yv = None
        if y_val is not None and len(y_val):
            yv = torch.tensor(np.searchsorted(self.classes_,
                                              np.asarray(y_val)),
                              device=dev)

        best = float("inf")
        best_state = None
        best_epoch = 0
        # Large datasets use the full batch cap; small ones shrink the batch so
        # that every epoch still performs at least ~10 gradient steps. With one
        # step per epoch, 200 epochs would mean only 200 Adam updates.
        bs = int(min(self.batch_size, n))
        if n < self.batch_size:
            bs = int(max(16, min(bs, n // 10)))

        for epoch in range(1, max_epochs + 1):
            perm = torch.randperm(n, device=dev)
            for start in range(0, n, bs):
                idx = perm[start:start + bs]
                loss = self._loss(Xt[idx], yt[idx])
                opt.zero_grad(set_to_none=True)
                loss.backward()
                opt.step()

            if Xv is not None and yv is not None:
                with torch.no_grad():
                    val_nll = F.cross_entropy(self._forward(Xv), yv).item()
                if val_nll < best - 1e-4:
                    best = val_nll
                    best_epoch = epoch
                    best_state = {k: v.detach().clone() for k, v in
                                  dict(A=self.A, C=self.C,
                                       logit_w=self.logit_w,
                                       log_tau=self.log_tau).items()}
                elif epoch - best_epoch >= self.patience:
                    break

            if self.verbose and epoch % 20 == 0:
                with torch.no_grad():
                    tr = F.cross_entropy(self._forward(Xt), yt).item()
                print(f"  epoch {epoch:3d}  train nll {tr:.4f}"
                      + (f"  val nll {val_nll:.4f}" if Xv is not None else ""))

        if best_state is not None:
            self.A.data.copy_(best_state["A"])
            self.C.data.copy_(best_state["C"])
            self.logit_w.data.copy_(best_state["logit_w"])
            self.log_tau.data.copy_(best_state["log_tau"])
            self.best_epochs_ = max(1, best_epoch)
        else:
            self.best_epochs_ = max_epochs

        # Stage 3a: temperature scaling on the inner validation split. Refit
        # keeps the temperature chosen here, so it is never fitted on data that
        # overlaps the test fold.
        if (self.temperature and Xv is not None and yv is not None
                and len(Xv) >= 100):
            with torch.no_grad():
                val_logits = self._forward(Xv)
            self.temperature_ = self._fit_temperature(val_logits, yv)
        elif self.temperature and Xv is not None and len(Xv) < 100:
            # Too few validation points: fitting a temperature would overfit.
            self.temperature_ = 1.0
        return self

    # ------------------------------------------------------------- internals
    def _metric(self):
        if self.share_metric:
            # One frame for all classes: QR of the class-mean frame.
            A = self.A.mean(dim=0, keepdim=True)          # (1, r, d)
            q, _ = torch.linalg.qr(A.transpose(1, 2))     # (1, d, r)
            return q.transpose(1, 2).expand(self.A.shape[0], -1, -1)
        q, _ = torch.linalg.qr(self.A.transpose(1, 2))   # (K, d, r)
        return q.transpose(1, 2)                          # (K, r, d)

    def _tau2(self):
        t = torch.exp(2.0 * self.log_tau).clamp_min(1e-6)
        if self.share_tau:
            t = t.expand(self.K_)
        return t.view(self.K_, 1, 1)

    def _forward(self, Xb):
        L = self._metric()
        Z = torch.einsum("bd,krd->bkr", Xb, L)            # (b, K, r)
        Cp = torch.einsum("knd,krd->knr", self.C, L)      # (K, n, r)
        d2 = torch.cdist(Z.permute(1, 0, 2), Cp).pow(2)   # (K, b, n)
        tau2 = self._tau2()
        if self.evidence == "gaussian":
            log_phi = -d2 / (2.0 * tau2)
        elif self.evidence == "rational":
            # heavy-tailed kernel: phi(d) = 1 / (1 + d^2 / tau^2)
            log_phi = -torch.log1p(d2 / tau2)
        else:
            raise ValueError(f"unknown evidence function {self.evidence!r}")
        log_w = F.log_softmax(self.logit_w, dim=1).unsqueeze(1)
        log_e = torch.logsumexp(log_w + log_phi, dim=2)   # (K, b)
        return log_e.transpose(0, 1) + torch.log(self.pi.clamp_min(1e-12))

    def _loss(self, Xb, yb):
        nll = F.cross_entropy(self._forward(Xb), yb)
        reg = self.lambda_ent * self._entropy()
        if self.lambda_sep:
            reg = reg + self.lambda_sep * self._separation()
        if self.lambda_sm:
            reg = reg + self.lambda_sm * self._smoothness()
        return nll + reg

    def _separation(self):
        pen = 0.0
        for k in range(self.K_):
            nk = self.n_k_eff[k]
            if nk < 2:
                continue
            ck = self.C[k, :nk]
            dm = torch.cdist(ck, ck)
            r, cidx = torch.triu_indices(nk, nk, offset=1, device=dm.device)
            pen = pen + F.relu(self.delta[k] - dm[r, cidx]).pow(2).mean()
        return pen / self.K_

    def _smoothness(self):
        # Proxy for the curvature of both kernels: they are controlled by tau.
        return (1.0 / self._tau2()).mean()

    def _entropy(self):
        log_w = F.log_softmax(self.logit_w, dim=1)
        return (log_w.exp() * log_w).mean()

    @torch.no_grad()
    def _fit_temperature(self, logits, y, lo=0.5, hi=10.0, n_grid=24):
        """Grid search over a single temperature on the validation split.

        A grid is more robust than gradient steps when the validation split is
        small; `lo=0.5` also prevents the degenerate sharpening solution that a
        free optimiser finds on a handful of points.
        """
        grid = torch.logspace(np.log10(lo), np.log10(hi), n_grid,
                              device=logits.device)
        best_t, best_nll = 1.0, float("inf")
        for t_val in grid:
            nll = F.cross_entropy(logits / t_val, y).item()
            if nll < best_nll:
                best_t, best_nll = float(t_val), nll
        return best_t

    # ------------------------------------------------------------ prediction
    @torch.no_grad()
    def _logits(self, X):
        Xt = torch.tensor(np.asarray(X, dtype=np.float32), device=self.device)
        out = []
        for start in range(0, len(Xt), 8192):
            out.append(self._forward(Xt[start:start + 8192]))
        return torch.cat(out, dim=0)

    def predict_proba(self, X):
        logits = self._logits(X)
        t_val = max(float(self.temperature_), 1e-3)
        return torch.softmax(logits / t_val, dim=1).cpu().numpy()

    def predict_evidence(self, X):
        """Log evidence max_k log e_k(x); higher means more in-distribution."""
        logits = self._logits(X)
        log_e = logits - torch.log(self.pi.clamp_min(1e-12))
        return log_e.max(dim=1).values.cpu().numpy()
