"""Shared base classifier for the post-hoc baselines."""
import numpy as np
from sklearn.linear_model import LogisticRegression


def fit_logreg(X, y, C=1.0, max_iter=500, seed=0):
    clf = LogisticRegression(C=C, max_iter=max_iter, random_state=seed)
    clf.fit(X, y)
    return clf


def aligned_proba(clf, X, classes):
    """Return probabilities on the global class grid."""
    p = clf.predict_proba(X)
    if len(clf.classes_) == len(classes) and np.array_equal(clf.classes_, classes):
        return p
    full = np.zeros((len(X), len(classes)), dtype=np.float64)
    idx = np.searchsorted(classes, clf.classes_)
    full[:, idx] = p
    return full
