"""Mahalanobis OOD baseline (Lee et al., NeurIPS 2018).

Re-implemented from the paper: the official repository declares no licence.
Class-conditional means plus a shared or class-specific covariance, scored by
the squared Mahalanobis distance.
"""
from __future__ import annotations
import numpy as np
from sklearn.covariance import LedoitWolf

from ..base import BaseMethod


class MahalanobisOOD(BaseMethod):
    name = "mahalanobis"

    def __init__(self, covariance="shared", shrinkage=1e-3):
        self.covariance = covariance
        self.shrinkage = shrinkage

    def fit(self, X_train, y_train, X_val=None, y_val=None):
        X = np.asarray(X_train, dtype=np.float64)
        y = np.asarray(y_train)
        self.classes_ = np.unique(y)
        d = X.shape[1]

        self.means_ = np.stack([X[y == c].mean(axis=0) for c in self.classes_])
        resid = X - self.means_[np.searchsorted(self.classes_, y)]

        if self.covariance == "shared":
            cov = np.cov(resid, rowvar=False)
            cov = np.atleast_2d(cov)
            cov = (1 - self.shrinkage) * cov + self.shrinkage * np.eye(d)
            self.prec_ = np.linalg.pinv(cov)
            self.logdet_ = float(np.linalg.slogdet(cov)[1])
            self.precs_ = None
        elif self.covariance == "class":
            self.precs_ = []
            self.logdets_ = []
            for ki, c in enumerate(self.classes_):
                R = resid[y == c]
                if R.shape[0] < 5:
                    cov = np.eye(d)
                else:
                    cov = LedoitWolf().fit(R).covariance_
                self.precs_.append(np.linalg.pinv(cov))
                self.logdets_.append(float(np.linalg.slogdet(cov)[1]))
        else:
            raise ValueError("covariance must be 'shared' or 'class'")
        return self

    def _d2(self, X):
        X = np.asarray(X, dtype=np.float64)
        out = np.empty((len(X), len(self.classes_)), dtype=np.float64)
        for ki in range(len(self.classes_)):
            diff = X - self.means_[ki]
            P = self.precs_[ki] if self.precs_ is not None else self.prec_
            # diff @ P is (n,d)@(d,d) and dispatches to BLAS.  The equivalent
            # three-operand einsum "nd,de,ne->n" has no BLAS path and falls
            # back to a scalar loop that is ~30x slower at d=512.
            out[:, ki] = ((diff @ P) * diff).sum(axis=1)
        return out

    def predict_proba(self, X):
        d2 = self._d2(X)
        z = -0.5 * d2
        z -= z.max(axis=1, keepdims=True)
        e = np.exp(z)
        return e / e.sum(axis=1, keepdims=True)

    def predict_evidence(self, X):
        """Negative nearest-class Mahalanobis distance: higher = more in-dist."""
        return -self._d2(X).min(axis=1)
