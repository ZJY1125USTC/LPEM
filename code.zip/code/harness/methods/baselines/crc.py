"""Conformal Risk Control baseline (Angelopoulos et al., ICLR 2024).

Official repository (aangelopoulos/conformal-risk) is MIT; this is a compact
re-implementation of split conformal risk control for selective prediction with
the 0-1 loss, so the threshold is comparable to LPEM's evidence threshold.
"""
from __future__ import annotations
import numpy as np

from ..base import BaseMethod
from ._base import fit_logreg, aligned_proba


class ConformalRiskControl(BaseMethod):
    name = "crc"

    def __init__(self, alpha=0.1, delta=0.1, C=1.0, seed=0):
        self.alpha = alpha
        self.delta = delta
        self.C = C
        self.seed = seed

    def fit(self, X_train, y_train, X_val=None, y_val=None):
        X = np.asarray(X_train, dtype=np.float64)
        y = np.asarray(y_train)
        self.classes_ = np.unique(y)
        self.base_ = fit_logreg(X, y, self.C, seed=self.seed)

        if X_val is None or len(X_val) < 20:
            # no calibration set: fall back to an internal split of the training data
            from sklearn.model_selection import train_test_split
            idx = np.arange(len(y))
            try:
                a, b = train_test_split(idx, test_size=0.2, stratify=y,
                                        random_state=self.seed)
            except ValueError:
                # a class with a single member cannot be stratified
                a, b = train_test_split(idx, test_size=0.2,
                                        random_state=self.seed)
            self.base_ = fit_logreg(X[a], y[a], self.C, seed=self.seed)
            Xc, yc = X[b], y[b]
        else:
            Xc, yc = np.asarray(X_val, dtype=np.float64), np.asarray(y_val)

        p = aligned_proba(self.base_, Xc, self.classes_)
        pred = p.argmax(1)
        err = (pred != yc).astype(np.float64)
        conf = p.max(1)

        # candidate acceptance thresholds on the confidence
        grid = np.unique(np.quantile(conf, np.linspace(0.5, 1.0, 200)))
        best = None
        n = len(yc)
        for t in grid:
            acc = conf >= t
            if acc.sum() == 0:
                continue
            risk = err[acc].mean()
            corrected = n / (n + 1.0) * risk + 1.0 / (n + 1.0)
            if corrected <= self.alpha:
                best = t
                break
        self.threshold_ = float(best) if best is not None else 1.0 + 1e-9
        self.coverage_ = float((conf >= self.threshold_).mean())
        self.cal_risk_ = float(err[conf >= self.threshold_].mean()) \
            if (conf >= self.threshold_).any() else 0.0
        return self

    def refit(self, X_train, y_train):
        """Refit the base classifier on the full training fold while keeping the
        conformal threshold calibrated on the inner validation split.

        The inherited ``BaseMethod.refit`` calls ``fit(..., None, None)``,
        which falls back to an *internal* 80/20 split of the training fold and
        therefore discards the outer inner-validation split used by every other
        method.  Restoring the threshold keeps the split-conformal guarantee
        attached to the calibration set that was actually held out.
        """
        threshold = float(getattr(self, "threshold_", 1.0 + 1e-9))
        coverage = float(getattr(self, "coverage_", 1.0))
        cal_risk = float(getattr(self, "cal_risk_", 0.0))
        X = np.asarray(X_train, dtype=np.float64)
        y = np.asarray(y_train)
        self.classes_ = np.unique(y)
        self.base_ = fit_logreg(X, y, self.C, seed=self.seed)
        self.threshold_ = threshold
        self.coverage_ = coverage
        self.cal_risk_ = cal_risk
        return self

    def predict_proba(self, X):
        X = np.asarray(X, dtype=np.float64)
        return aligned_proba(self.base_, X, self.classes_)

    def predict_evidence(self, X):
        """Confidence; accepting conf >= threshold_ implements the CRC rule."""
        return self.predict_proba(X).max(axis=1)
