"""DUQ baseline (van Amersfoort et al., ICML 2020).

Official repository (y0ast/deterministic-uncertainty-quantification) is MIT.
This is a tabular re-implementation: an MLP trunk, L2-normalised embeddings,
one centroid per class updated by an exponential moving average, and an RBF
kernel whose bandwidth is learned.

Loss follows the centripetal form: pull embeddings towards their class centroid
with a margin, and push them away from the other centroids.
"""
from __future__ import annotations
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from ..base import BaseMethod
from ._temperature import fit_temperature


def _pair_d2(z, c):
    """Squared Euclidean distance with full double-backward support.
    torch.cdist has no second derivative, which the gradient penalty needs."""
    return (z.unsqueeze(1) - c.unsqueeze(0)).pow(2).sum(-1)


class _MLP(nn.Module):
    def __init__(self, d_in, hidden, d_out):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_in, hidden), nn.ReLU(), nn.Dropout(0.1),
            nn.Linear(hidden, hidden), nn.ReLU(), nn.Dropout(0.1),
            nn.Linear(hidden, d_out),
        )

    def forward(self, x):
        z = self.net(x)
        return F.normalize(z, dim=1)


class DUQ(BaseMethod):
    name = "duq"

    def __init__(self, emb_dim=64, hidden=128, epochs=200, lr=1e-3,
                 batch_size=512, margin=0.1, sigma=0.1, patience=20,
                 weight_decay=1e-4, grad_penalty=0.1, seed=0, device=None):
        self.emb_dim = emb_dim
        self.hidden = hidden
        self.epochs = epochs
        self.lr = lr
        self.batch_size = batch_size
        self.margin = margin
        self.sigma = sigma
        self.patience = patience
        self.weight_decay = weight_decay
        self.grad_penalty = grad_penalty
        self.seed = seed
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")

    def _forward(self, x):
        z = self.net_(x)
        d2 = _pair_d2(z, self.centroids_)      # (b, K)
        sigma2 = torch.exp(2.0 * self.log_sigma_).clamp_min(1e-6)
        return -d2 / (2.0 * sigma2)

    def fit(self, X_train, y_train, X_val=None, y_val=None):
        torch.manual_seed(self.seed)
        rng = np.random.default_rng(self.seed)
        X = np.asarray(X_train, dtype=np.float32)
        y = np.asarray(y_train)
        self.classes_ = np.unique(y)
        y_idx = np.searchsorted(self.classes_, y)
        K = len(self.classes_)
        d = X.shape[1]

        self.net_ = _MLP(d, self.hidden, self.emb_dim).to(self.device)
        self.centroids_ = torch.zeros(K, self.emb_dim, device=self.device)
        self.log_sigma_ = torch.tensor(np.log(self.sigma), dtype=torch.float32,
                                       device=self.device, requires_grad=True)

        # initialise centroids from class means of the untrained embedding
        with torch.no_grad():
            z = self.net_(torch.tensor(X, device=self.device))
            for k in range(K):
                if (y_idx == k).any():
                    self.centroids_[k] = z[torch.tensor(y_idx == k, device=self.device)].mean(0)
            self.centroids_ = F.normalize(self.centroids_, dim=1)

        params = list(self.net_.parameters()) + [self.log_sigma_]
        opt = torch.optim.Adam(params, lr=self.lr,
                               weight_decay=self.weight_decay)

        Xt = torch.tensor(X, device=self.device)
        yt = torch.tensor(y_idx, device=self.device)
        Xv = torch.tensor(np.asarray(X_val, dtype=np.float32), device=self.device) \
            if X_val is not None and len(X_val) else None
        yv = torch.tensor(np.searchsorted(self.classes_, np.asarray(y_val)),
                          device=self.device) if y_val is not None and len(y_val) else None

        n = len(Xt)
        bs = int(min(self.batch_size, n))
        if n < self.batch_size:
            bs = int(max(16, min(bs, n // 10)))

        # The gradient penalty needs a second derivative through the trunk,
        # which is ~50x more expensive than the forward pass. On large data we
        # apply it periodically on a sub-batch and cap the epoch budget; the
        # centripetal term still sees every sample.
        if n > 50_000:
            bs = max(bs, 2048)
            gp_every, gp_sub = 10, 256
            max_epochs = min(self.epochs, 80)
        elif n > 10_000:
            gp_every, gp_sub = 5, 256
            max_epochs = min(self.epochs, 120)
        else:
            gp_every, gp_sub = 1, bs
            max_epochs = self.epochs

        best, best_state, best_epoch = float("inf"), None, 0

        step = 0
        for epoch in range(1, max_epochs + 1):
            self.net_.train()
            perm = torch.randperm(n, device=self.device)
            for start in range(0, n, bs):
                idx = perm[start:start + bs]
                xb, yb = Xt[idx], yt[idx]
                z = self.net_(xb)
                d2 = _pair_d2(z, self.centroids_)
                intra = d2.gather(1, yb.view(-1, 1)).squeeze(1)
                mask = F.one_hot(yb, K).bool()
                inter = (d2.masked_fill(mask, 0.0).sum(1) / max(K - 1, 1))
                loss = (F.relu(intra - self.margin).pow(2) - inter).mean()

                # DUQ's gradient penalty keeps the RBF kernel 1-Lipschitz;
                # without it the trunk collapses every class to a single point.
                step += 1
                if self.grad_penalty and (step % gp_every == 0):
                    xg = xb[:gp_sub].detach().clone().requires_grad_(True)
                    zg = self.net_(xg)
                    d2g = _pair_d2(zg, self.centroids_)
                    k = torch.exp(-d2g.gather(1, yb[:gp_sub].view(-1, 1)).squeeze(1)
                                  / (2.0 * torch.exp(2.0 * self.log_sigma_).clamp_min(1e-6)))
                    g = torch.autograd.grad(k.sum(), xg, create_graph=True)[0]
                    loss = loss + self.grad_penalty * ((g.norm(dim=1) - 1.0) ** 2).mean()

                opt.zero_grad(set_to_none=True)
                loss.backward()
                opt.step()

                # EMA centroid update, no gradient
                with torch.no_grad():
                    for k in range(K):
                        m = yb == k
                        if m.any():
                            c = z[m].mean(0)
                            self.centroids_[k] = F.normalize(
                                0.99 * self.centroids_[k] + 0.01 * c, dim=0)

            if Xv is not None and yv is not None:
                self.net_.eval()
                with torch.no_grad():
                    val = F.cross_entropy(self._forward(Xv), yv).item()
                if val < best - 1e-4:
                    best, best_epoch = val, epoch
                    best_state = {k: v.detach().clone() for k, v in
                                  self.net_.state_dict().items()}
                elif epoch - best_epoch >= self.patience:
                    break

        if best_state is not None:
            self.net_.load_state_dict(best_state)
        self.net_.eval()

        self.temperature_ = 1.0
        if Xv is not None and yv is not None and len(Xv) >= 100:
            with torch.no_grad():
                self.temperature_ = fit_temperature(self._forward(Xv), yv)
        return self

    def refit(self, X_train, y_train):
        # Refit must not discard the temperature chosen on the validation split.
        temperature = getattr(self, "temperature_", 1.0)
        self.fit(X_train, y_train, None, None)
        self.temperature_ = temperature
        return self

    @torch.no_grad()
    def _logits(self, X):
        self.net_.eval()
        Xt = torch.tensor(np.asarray(X, dtype=np.float32), device=self.device)
        out = [self._forward(Xt[i:i + 8192]) for i in range(0, len(Xt), 8192)]
        return torch.cat(out, dim=0)

    def predict_proba(self, X):
        t = max(float(getattr(self, "temperature_", 1.0)), 1e-3)
        return torch.softmax(self._logits(X) / t, dim=1).cpu().numpy()

    def predict_evidence(self, X):
        return self._logits(X).max(dim=1).values.cpu().numpy()
