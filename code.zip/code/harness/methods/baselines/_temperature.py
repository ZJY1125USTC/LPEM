"""Shared post-hoc temperature scaling for the neural baselines."""
import numpy as np
import torch
import torch.nn.functional as F


@torch.no_grad()
def fit_temperature(logits, y, lo=0.5, hi=200.0, n_grid=48):
    grid = torch.logspace(np.log10(lo), np.log10(hi), n_grid,
                          device=logits.device)
    best_t, best = 1.0, float("inf")
    for t in grid:
        nll = F.cross_entropy(logits / t, y).item()
        if nll < best:
            best, best_t = nll, float(t)
    return best_t
