"""Dirichlet calibration baseline (Kull et al., NeurIPS 2019).

Official repository dirichletcal/dirichlet_python is MIT; this implements the
matrix-scaling form p' = softmax(W log p + b), fitted on a calibration split
with L2 shrinkage towards the identity map.
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize

from ..base import BaseMethod
from ._base import fit_logreg, aligned_proba


class DirichletCalibration(BaseMethod):
    name = "dirichlet"

    def __init__(self, reg=1e-3, C=1.0, seed=0):
        self.reg = reg
        self.C = C
        self.seed = seed

    def fit(self, X_train, y_train, X_val=None, y_val=None):
        X = np.asarray(X_train, dtype=np.float64)
        y = np.asarray(y_train)
        self.classes_ = np.unique(y)
        self.base_ = fit_logreg(X, y, self.C, seed=self.seed)

        K = len(self.classes_)
        self.W_ = np.eye(K)
        self.b_ = np.zeros(K)

        if X_val is None or len(X_val) < 20:
            return self

        Xc = np.asarray(X_val, dtype=np.float64)
        yc = np.asarray(y_val)
        logp = self._log_base(Xc)
        y_idx = np.searchsorted(self.classes_, yc)
        n = len(yc)
        I = np.eye(K)

        def objective(theta):
            W = theta[:K * K].reshape(K, K)
            b = theta[K * K:]
            Z = logp @ W.T + b
            Z -= Z.max(axis=1, keepdims=True)
            P = np.exp(Z)
            P /= P.sum(axis=1, keepdims=True)
            loss = -np.mean(np.log(np.clip(P[np.arange(n), y_idx], 1e-12, 1.0)))
            loss += self.reg * (np.sum((W - I) ** 2) + np.sum(b ** 2))

            G = P.copy()
            G[np.arange(n), y_idx] -= 1.0
            G /= n
            gW = G.T @ logp + 2.0 * self.reg * (W - I)
            gb = G.sum(axis=0) + 2.0 * self.reg * b
            return loss, np.concatenate([gW.ravel(), gb])

        theta0 = np.concatenate([I.ravel(), np.zeros(K)])
        res = minimize(objective, theta0, jac=True, method="L-BFGS-B",
                       options={"maxiter": 500})
        self.W_ = res.x[:K * K].reshape(K, K)
        self.b_ = res.x[K * K:]
        return self

    def refit(self, X_train, y_train):
        """Refit the base classifier on the full training fold while keeping the
        calibration map that was fitted on the inner validation split.

        Without this override the inherited ``BaseMethod.refit`` calls
        ``fit(..., None, None)``, which resets ``W_`` to the identity and
        silently degrades this baseline to an uncalibrated logistic
        regression.  Keeping the map is the same convention already used by
        the DUQ and SelectiveNet baselines for their temperatures: the
        post-hoc parameters are estimated once on data that never enters the
        gradient update and are then frozen.
        """
        W = np.array(getattr(self, "W_", np.eye(1)), copy=True)
        b = np.array(getattr(self, "b_", np.zeros(1)), copy=True)
        self.fit(X_train, y_train, None, None)
        # Guard against a fold whose class set differs from the inner split.
        if W.shape == self.W_.shape:
            self.W_, self.b_ = W, b
        return self

    def _log_base(self, X):
        p = aligned_proba(self.base_, X, self.classes_)
        logp = np.log(np.clip(p, 1e-12, 1.0))
        logp -= logp.mean(axis=1, keepdims=True)
        return logp

    def predict_proba(self, X):
        Z = self._log_base(np.asarray(X, dtype=np.float64)) @ self.W_.T + self.b_
        Z -= Z.max(axis=1, keepdims=True)
        P = np.exp(Z)
        return P / P.sum(axis=1, keepdims=True)
