"""Distance-weighted k-nearest-neighbour reference (Dudani, 1976).

Votes are weighted by 1/distance.  The posterior is the normalised weighted
vote with a uniform smoothing of eps per class, and the evidence score is the
maximum posterior.  k = 10 for every dataset: the method enters the comparison
as a fixed reference of the distance-weighted family, not as a tuned
competitor.

Neighbours are found by chunked brute force on the GPU when one is available
(the large tabular sets have up to 3.2e5 training points), and by sklearn
otherwise.  Both paths return the same quantity.
"""
from __future__ import annotations
import numpy as np

from ..base import BaseMethod

try:
    import torch
except Exception:  # pragma: no cover
    torch = None


class WeightedKNN(BaseMethod):
    name = "wknn"

    def __init__(self, k=10, eps=1e-3, chunk=512):
        self.k = int(k)
        self.eps = float(eps)
        self.chunk = int(chunk)

    def fit(self, X_train, y_train, X_val=None, y_val=None):
        X = np.asarray(X_train, dtype=np.float32)
        y = np.asarray(y_train).astype(np.int64)
        self.classes_ = np.unique(y)
        self.k_ = int(min(self.k, max(1, len(X))))
        self.X_ = X
        self.y_ = np.searchsorted(self.classes_, y).astype(np.int64)
        self.use_gpu_ = bool(torch is not None and torch.cuda.is_available() and len(X) > 2000)
        if self.use_gpu_:
            self.Xt_ = torch.from_numpy(X).cuda()
            self.yt_ = torch.from_numpy(self.y_).cuda()
        return self

    def refit(self, X_train, y_train):
        return self.fit(X_train, y_train)

    def _proba_gpu(self, X):
        out = np.empty((len(X), len(self.classes_)), dtype=np.float64)
        for s in range(0, len(X), self.chunk):
            xb = torch.from_numpy(X[s:s + self.chunk]).cuda()
            d2 = torch.cdist(xb, self.Xt_).clamp_min_(0.0)
            vals, idx = torch.topk(d2, self.k_, dim=1, largest=False, sorted=False)
            w = 1.0 / (vals + 1e-6)
            lab = self.yt_[idx]
            W = torch.zeros((xb.shape[0], len(self.classes_)), device=xb.device)
            W.scatter_add_(1, lab, w)
            W = W / W.sum(dim=1, keepdim=True)
            out[s:s + self.chunk] = W.double().cpu().numpy()
        return out

    def _proba_cpu(self, X):
        from sklearn.neighbors import NearestNeighbors
        nn = NearestNeighbors(n_neighbors=self.k_, algorithm="brute", n_jobs=-1)
        nn.fit(self.X_)
        vals, idx = nn.kneighbors(X)
        w = 1.0 / (vals + 1e-6)
        lab = self.y_[idx]
        W = np.zeros((len(X), len(self.classes_)), dtype=np.float64)
        for j in range(self.k_):
            np.add.at(W, (np.arange(len(X)), lab[:, j]), w[:, j])
        return W / W.sum(axis=1, keepdims=True)


    def predict_negdist(self, X):
        """Negative mean distance to the k nearest neighbours.

        Higher values mean a query sits close to its neighbours, so the score
        has the same orientation as the other in-distribution scores.
        """
        X = np.asarray(X, dtype=np.float32)
        if self.use_gpu_:
            out = np.empty(len(X), dtype=np.float64)
            for s in range(0, len(X), self.chunk):
                xb = torch.from_numpy(X[s:s + self.chunk]).cuda()
                d = torch.cdist(xb, self.Xt_)
                vals, _ = torch.topk(d, self.k_, dim=1, largest=False, sorted=False)
                out[s:s + self.chunk] = -vals.mean(dim=1).double().cpu().numpy()
            return out
        from sklearn.neighbors import NearestNeighbors
        nn = NearestNeighbors(n_neighbors=self.k_, algorithm="brute", n_jobs=-1)
        nn.fit(self.X_)
        vals, _ = nn.kneighbors(X)
        return -vals.mean(axis=1)

    def predict_proba(self, X):
        X = np.asarray(X, dtype=np.float32)
        raw = self._proba_gpu(X) if self.use_gpu_ else self._proba_cpu(X)
        return (raw + self.eps) / (1.0 + self.eps * len(self.classes_))