"""SelectiveNet baseline (Geifman & El-Yaniv, ICML 2019).

The official repository declares no licence, so this is a re-implementation:
a shared MLP trunk with a prediction head, a selection head and an auxiliary
head, trained with a coverage-constrained selective risk.
"""
from __future__ import annotations
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from ..base import BaseMethod
from ._temperature import fit_temperature


class _Heads(nn.Module):
    def __init__(self, d_in, hidden, n_classes):
        super().__init__()
        self.trunk = nn.Sequential(
            nn.Linear(d_in, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
        )
        self.pred = nn.Linear(hidden, n_classes)
        self.select = nn.Linear(hidden, 1)
        self.aux = nn.Linear(hidden, n_classes)

    def forward(self, x):
        h = self.trunk(x)
        return self.pred(h), self.select(h).squeeze(1), self.aux(h)


class SelectiveNet(BaseMethod):
    name = "selective"

    def __init__(self, hidden=128, epochs=200, lr=1e-3, batch_size=512,
                 coverage=0.8, lam=32.0, aux_weight=0.5, patience=20,
                 seed=0, device=None):
        self.hidden = hidden
        self.epochs = epochs
        self.lr = lr
        self.batch_size = batch_size
        self.coverage = coverage
        self.lam = lam
        self.aux_weight = aux_weight
        self.patience = patience
        self.seed = seed
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")

    def fit(self, X_train, y_train, X_val=None, y_val=None):
        torch.manual_seed(self.seed)
        X = np.asarray(X_train, dtype=np.float32)
        y = np.asarray(y_train)
        self.classes_ = np.unique(y)
        y_idx = np.searchsorted(self.classes_, y)
        K = len(self.classes_)
        d = X.shape[1]

        self.model_ = _Heads(d, self.hidden, K).to(self.device)
        opt = torch.optim.Adam(self.model_.parameters(), lr=self.lr)

        Xt = torch.tensor(X, device=self.device)
        yt = torch.tensor(y_idx, device=self.device)
        Xv = torch.tensor(np.asarray(X_val, dtype=np.float32), device=self.device) \
            if X_val is not None and len(X_val) else None
        yv = torch.tensor(np.searchsorted(self.classes_, np.asarray(y_val)),
                          device=self.device) if y_val is not None and len(y_val) else None

        n = len(Xt)
        bs = int(min(self.batch_size, n))
        if n < self.batch_size:
            bs = int(max(16, min(bs, n // 10)))

        # Match LPEM/DUQ: large datasets spend less time per epoch and use a
        # smaller epoch budget, otherwise 25 folds take hours.
        if n > 50_000:
            bs = max(bs, 2048)
            max_epochs = min(self.epochs, 80)
        elif n > 10_000:
            bs = max(bs, 1024)
            max_epochs = min(self.epochs, 120)
        else:
            max_epochs = self.epochs

        best, best_state, best_epoch = float("inf"), None, 0

        for epoch in range(1, max_epochs + 1):
            self.model_.train()
            perm = torch.randperm(n, device=self.device)
            for start in range(0, n, bs):
                idx = perm[start:start + bs]
                xb, yb = Xt[idx], yt[idx]
                logits, g_logit, aux_logits = self.model_(xb)
                g = torch.sigmoid(g_logit)
                ce = F.cross_entropy(logits, yb, reduction="none")
                denom = g.sum().clamp_min(1e-6)
                sel_risk = (g * ce).sum() / denom
                cov = g.mean()
                loss = sel_risk + self.lam * F.relu(self.coverage - cov).pow(2)
                loss = loss + self.aux_weight * F.cross_entropy(aux_logits, yb)

                opt.zero_grad(set_to_none=True)
                loss.backward()
                opt.step()

            if Xv is not None and yv is not None:
                self.model_.eval()
                with torch.no_grad():
                    logits, g_logit, _ = self.model_(Xv)
                    val = F.cross_entropy(logits, yv).item()
                if val < best - 1e-4:
                    best, best_epoch = val, epoch
                    best_state = {k: v.detach().clone() for k, v in
                                  self.model_.state_dict().items()}
                elif epoch - best_epoch >= self.patience:
                    break

        if best_state is not None:
            self.model_.load_state_dict(best_state)
        self.model_.eval()

        self.temperature_ = 1.0
        if Xv is not None and yv is not None and len(Xv) >= 100:
            with torch.no_grad():
                logits_v, _, _ = self.model_(Xv)
                self.temperature_ = fit_temperature(logits_v, yv)
        return self

    def refit(self, X_train, y_train):
        # Refit must not discard the temperature chosen on the validation split.
        temperature = getattr(self, "temperature_", 1.0)
        self.fit(X_train, y_train, None, None)
        self.temperature_ = temperature
        return self

    @torch.no_grad()
    def _predict(self, X):
        self.model_.eval()
        Xt = torch.tensor(np.asarray(X, dtype=np.float32), device=self.device)
        logits, g_logit, _ = [], [], []
        for i in range(0, len(Xt), 8192):
            l, g, _ = self.model_(Xt[i:i + 8192])
            logits.append(l); g_logit.append(g)
        return torch.cat(logits), torch.cat(g_logit)

    def predict_proba(self, X):
        logits, _ = self._predict(X)
        t = max(float(getattr(self, "temperature_", 1.0)), 1e-3)
        return torch.softmax(logits / t, dim=1).cpu().numpy()

    def predict_evidence(self, X):
        _, g_logit = self._predict(X)
        return torch.sigmoid(g_logit).cpu().numpy()
