# -*- coding: utf-8 -*-
import os, sys, glob, json
from pathlib import Path
import pandas as pd, numpy as np
HERE = str(Path(__file__).resolve().parent)
os.chdir(HERE); sys.path.insert(0, HERE)
import aggregate as A
F = sorted(glob.glob("results_final/*__*.csv")) + sorted(glob.glob("results_knn/*__wknn.csv"))
df = pd.concat([pd.read_csv(f) for f in F], ignore_index=True)
num = json.load(open("reports/ch6/numbers.json", encoding="utf-8"))
IID, SHIFT = num["iid"], num["shifted"]
METRICS = ["acc","macro_f1","nll","brier","ece","mce","aurc","selrisk80"]
ORDER = ["mahalanobis","wknn","crc","dirichlet","lpem","duq","selective"]
LAB = {"mahalanobis":"Mahalanobis","wknn":"wkNN","crc":"CRC","dirichlet":"Dirichlet",
       "lpem":"LPEM","duq":"DUQ","selective":"SelectiveNet"}
iid = df[df.dataset.isin(IID)]
s = iid.groupby(["dataset","method"])[METRICS].mean().reset_index()
out = {"order": ORDER, "label": LAB, "metrics": METRICS, "pooled": {}, "ranks": {}, "friedman_p": {}}
for m in METRICS:
    out["pooled"][m] = {k: [float(s[s.method==k][m].mean()), float(s[s.method==k][m].std())] for k in ORDER}
for m in METRICS:
    r = A.friedman_and_cd(iid, m)
    out["ranks"][m] = {k: float(v) for k, v in r["mean_ranks"].items()}
    out["friedman_p"][m] = float(r["p_value"])
    out.setdefault("cd", {})[m] = float(r["cd"])
overall = {k: float(np.mean([out["ranks"][m][k] for m in METRICS])) for k in ORDER}
out["overall_rank"] = overall
# all-26 pooled ranks
allr = {}
for m in METRICS:
    r = A.friedman_and_cd(df, m)
    allr[m] = {k: float(v) for k, v in r["mean_ranks"].items()}
out["ranks_all26"] = allr
out["overall_rank_all26"] = {k: float(np.mean([allr[m][k] for m in METRICS])) for k in ORDER}
# shifted per-dataset accuracy + means over 7 metrics
sh = df[df.dataset.isin(SHIFT)].groupby(["dataset","method"])[METRICS].mean()
out["shifted"] = {ds: {k: {m: float(sh.loc[(ds,k),m]) for m in METRICS} for k in ORDER} for ds in SHIFT}
out["shifted_mean"] = {k: {m: float(sh.loc[(slice(None),k),m].mean()) for m in METRICS} for k in ORDER}
# counts
best_mean, best_rank = [], []
for m in METRICS:
    vals = {k: out["pooled"][m][k][0] for k in ORDER}
    bm = max(vals, key=vals.get) if m in ["acc","macro_f1"] else min(vals, key=vals.get)
    best_mean.append(bm)
    rk = out["ranks"][m]
    best_rank.append(min(rk, key=rk.get))
out["best_mean_by_metric"] = dict(zip(METRICS, best_mean))
out["best_rank_by_metric"] = dict(zip(METRICS, best_rank))
# accuracy wins per dataset
accwide = s.pivot(index="dataset", columns="method", values="acc")
out["l_pem_acc_wins"] = int((accwide.idxmax(axis=1) == "lpem").sum())
out["n_iid"] = len(IID)
json.dump(out, open("reports/ch6/numbers7.json","w",encoding="utf-8"), indent=1)
print("overall 22:", {LAB[k]: round(v,3) for k,v in overall.items()})
print("overall 26:", {LAB[k]: round(v,3) for k,v in out["overall_rank_all26"].items()})
print("best mean:", {m: LAB[v] for m,v in out["best_mean_by_metric"].items()})
print("best rank:", {m: LAB[v] for m,v in out["best_rank_by_metric"].items()})
print("LPEM acc wins:", out["l_pem_acc_wins"], "/", len(IID))
print("CD:", out["cd"]["acc"])
print("friedman p:", {m: round(v,4) for m,v in out["friedman_p"].items()})