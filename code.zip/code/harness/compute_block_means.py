import csv, glob, os
import numpy as np

base = os.path.join(os.getcwd(), "results_ablation")
shifted = {"vowel", "gas_sensor_drift", "har", "occupancy_detection"}
variants = ["full", "fixed_metric", "fixed_identity", "shared_metric", "single_proto", "no_reg", "no_temp"]
have = {v: sorted({os.path.basename(f).split("__")[0] for f in glob.glob(os.path.join(base, "*__lpem_" + v + ".csv"))}) for v in variants}
all_ds = sorted(have["full"])
print("full variant: %d datasets" % len(all_ds))
print("  iid: %d  shifted: %d" % (len([d for d in all_ds if d not in shifted]), len([d for d in all_ds if d in shifted])))

def load(ds, var):
    p = os.path.join(base, ds + "__lpem_" + var + ".csv")
    if not os.path.exists(p): return None
    rows = list(csv.DictReader(open(p, encoding="utf-8")))
    acc = np.array([float(r["acc"]) for r in rows])
    nll = np.array([float(r["nll"]) for r in rows])
    ece = np.array([float(r["ece"]) for r in rows])
    aurc = np.array([float(r["aurc"]) for r in rows])
    sr = np.array([float(r["selrisk80"]) for r in rows])
    return (acc.mean()*100, nll.mean(), ece.mean(), aurc.mean(), sr.mean()*100)

def block(ds_list, var):
    vals = [load(d, var) for d in ds_list]
    vals = [v for v in vals if v is not None]
    if not vals:
        return (np.nan, np.nan, np.nan, np.nan, np.nan), 0
    arr = np.array(vals)
    return arr.mean(axis=0), len(arr)

iid_full = [d for d in all_ds if d not in shifted]
sh_full = [d for d in all_ds if d in shifted]
fi, nfi = block(iid_full, "full")
fs, nfs = block(sh_full, "full")
print()
print("FULL iid(n=%d): acc=%.4f nll=%.4f ece=%.4f aurc=%.4f sr=%.4f" % (nfi, fi[0], fi[1], fi[2], fi[3], fi[4]))
print("FULL sh(n=%d):  acc=%.4f nll=%.4f ece=%.4f aurc=%.4f sr=%.4f" % (nfs, fs[0], fs[1], fs[2], fs[3], fs[4]))
print()
for var in ["fixed_metric", "fixed_identity", "shared_metric", "single_proto", "no_reg", "no_temp"]:
    ds = have[var]
    i8 = [d for d in ds if d not in shifted]
    s2 = [d for d in ds if d in shifted]
    bi, nbi = block(i8, var)
    bs, nbs = block(s2, var)
    print(var, "n=%d (%d iid + %d sh)" % (len(ds), len(i8), len(s2)))
    print("  iid: acc=%.4f d=%+.2f nll=%.4f d=%+.4f ece=%.4f d=%+.4f aurc=%.4f d=%+.4f sr=%.4f d=%+.2f" % (bi[0], bi[0]-fi[0], bi[1], bi[1]-fi[1], bi[2], bi[2]-fi[2], bi[3], bi[3]-fi[3], bi[4], bi[4]-fi[4]))
    print("  sh:  acc=%.4f d=%+.2f nll=%.4f d=%+.4f ece=%.4f d=%+.4f aurc=%.4f d=%+.4f sr=%.4f d=%+.2f" % (bs[0], bs[0]-fs[0], bs[1], bs[1]-fs[1], bs[2], bs[2]-fs[2], bs[3], bs[3]-fs[3], bs[4], bs[4]-fs[4]))