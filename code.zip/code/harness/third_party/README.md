# Third-party baselines: licensing and usage policy

This directory documents the five priority baselines used in Section 6.1.3.
**Official code is not vendored into this repository by default.** Only notes,
citations, and our own adapter code live here.

## 1. Verification table (checked 2026-10-22 via GitHub API / PyPI)

| # | Baseline | Paper | Official repository | License | May we copy code? |
|---|----------|-------|---------------------|---------|-------------------|
| 1 | DUQ | van Amersfoort et al., *Uncertainty Estimation Using a Single Deep Deterministic Neural Network*, ICML 2020 | `y0ast/deterministic-uncertainty-quantification` | **MIT** | Yes, with copyright + license notice |
| 2 | Mahalanobis OOD | Lee et al., *A Simple Unified Framework for Detecting Out-of-Distribution Samples and Adversarial Attacks*, NeurIPS 2018 | `pokaxpoka/deep_Mahalanobis_detector` | **None declared** | **No** - re-implement from the paper |
| 3 | SelectiveNet | Geifman & El-Yaniv, *SelectiveNet: A Deep Neural Network with an Integrated Reject Option*, ICML 2019 | `geifmany/selectivenet` | **None declared** | **No** - re-implement from the paper |
| 4 | Dirichlet calibration | Kull et al., *Beyond Temperature Scaling: Obtaining Well-Calibrated Multi-Class Probabilities with Dirichlet Calibration*, NeurIPS 2019 | `dirichletcal/dirichlet_python` (PyPI: `dirichletcal`) | **MIT** | Yes, with copyright + license notice |
| 5 | Conformal Risk Control | Angelopoulos et al., *Conformal Risk Control*, ICLR 2024 | `aangelopoulos/conformal-risk` | **MIT** | Yes, with copyright + license notice |

Status legend: **MIT** = permissive, reuse allowed with attribution; **None declared** =
no LICENSE file, therefore "all rights reserved" by default - do not copy or redistribute.

> Re-check before submission. Repository licenses can change, and the GitHub API
> returns the license detected at the repository root only.

## 2. What is and is not a risk

- **Copyright** is the real constraint. It covers the *code expression*, not the
  algorithm. Running official code locally to produce numbers is low risk;
  copying it into a repository that you release is not.
- **Patents** are not a practical concern for these five methods in an academic
  paper. They would matter for commercial deployment, which is out of scope.
- **Trademarks** are not a concern for scholarly reference. Do not use the
  authors' logos, and do not name your software after their methods.

## 3. Three usage strategies, in order of preference

1. **Re-implement from the paper (preferred).** No code-copyright exposure, and it
   is the only way to get a uniform `fit / predict_proba / predict_evidence`
   interface across all five baselines. Recommended for Mahalanobis and
   SelectiveNet, which have no license.
2. **Run official code in isolation.** Clone into `third_party/<method>/src/`
   (git-ignored), run locally to obtain numbers, never redistribute.
3. **Vendor licensed code.** Only for MIT-licensed repositories, and only with
   the full license text and copyright notice retained in
   `third_party/<method>/src/LICENSE`.

## 4. Citation and reporting

In Section 6.1.3, state for each baseline whether you used the official
implementation or your own re-implementation, and cite the original paper.
Suggested wording:

> We compare against DUQ [..], Mahalanobis OOD [..], SelectiveNet [..],
> Dirichlet calibration [..] and conformal risk control [..]. For DUQ,
> Dirichlet calibration and conformal risk control we use the official
> implementations; for Mahalanobis OOD and SelectiveNet, which do not
> distribute a license, we re-implement the published algorithms.

## 5. Dataset licences (separate issue)

Dataset terms are independent of code licences. In particular:

- Lending Club and Home Credit Default Risk are distributed under their own
  data-use terms; do not redistribute the raw files.
- CUB-200-2011, Omniglot, MNIST, CIFAR-10 and the UCI/OpenML datasets each carry
  their own terms.
- Release download scripts and checksums, not the data itself.

## 6. Directory layout

```
third_party/
  README.md                 this policy and verification table
  duq/README.md             notes + citation + decision
  mahalanobis/README.md
  selectivenet/README.md
  dirichlet/README.md
  crc/README.md
  <method>/src/             cloned or vendored code, git-ignored
```

This document is engineering guidance, not legal advice. Consult your
institution's technology-transfer office before any commercial use.
