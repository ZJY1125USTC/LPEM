# Conformal Risk Control

- **Official repository:** https://github.com/aangelopoulos/conformal-risk
- **License status (checked 2026-10-22):** MIT
- **Paper:** Angelopoulos, Bates, Fisch, Lei, Schuster. Conformal Risk Control. ICLR 2024.

## Decision

**Adapter over the official MIT implementation is allowed.** Keep the license notice if code is vendored.

## Experiment notes

Match the calibration-set size and the target risk alpha across methods. Report coverage, selective risk, risk gap and set size.

## Placement

Put cloned or vendored code in `third_party/crc/src/`. That directory is
git-ignored, so official code is never committed by accident.
