# DUQ - Deterministic Uncertainty Quantification

- **Official repository:** https://github.com/y0ast/deterministic-uncertainty-quantification
- **License status (checked 2026-10-22):** MIT
- **Paper:** van Amersfoort, Smith, Jesson, Ong. Uncertainty Estimation Using a Single Deep Deterministic Neural Network. ICML 2020.

## Decision

**Adapter over the official MIT implementation is allowed.** Keep the LICENSE file if code is vendored. Prefer a thin wrapper that maps DUQ's RBF kernel output to `predict_proba` and `predict_evidence`.

## Experiment notes

Single centroid per class plus a fixed RBF scale. Report ECE / NLL / Brier and AUROC / FPR95 under the same frozen features as LPEM.

## Placement

Put cloned or vendored code in `third_party/duq/src/`. That directory is
git-ignored, so official code is never committed by accident.
