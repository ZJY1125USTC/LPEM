# Dirichlet calibration

- **Official repository:** https://github.com/dirichletcal/dirichlet_python (PyPI: dirichletcal)
- **License status (checked 2026-10-22):** MIT
- **Paper:** Kull, Perello-Nieto, Kangsepp, Silva Filho, Song, Flach. Beyond Temperature Scaling: Obtaining Well-Calibrated Multi-Class Probabilities with Dirichlet Calibration. NeurIPS 2019.

## Decision

**Adapter over the official MIT implementation is allowed.** Prefer depending on the PyPI package rather than vendoring the source.

## Experiment notes

Two settings: post-hoc calibration of the LPEM posterior, and post-hoc calibration of each baseline. Report ECE / MCE / Brier / NLL with reliability diagrams.

## Placement

Put cloned or vendored code in `third_party/dirichlet/src/`. That directory is
git-ignored, so official code is never committed by accident.
