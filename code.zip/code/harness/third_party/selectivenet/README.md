# SelectiveNet

- **Official repository:** https://github.com/geifmany/selectivenet
- **License status (checked 2026-10-22):** None declared
- **Paper:** Geifman, El-Yaniv. SelectiveNet: A Deep Neural Network with an Integrated Reject Option. ICML 2019.

## Decision

**Re-implement from the paper.** No license is declared. The architecture is a shared trunk with a prediction head, a selection head and an auxiliary head, trained with a coverage-constrained objective.

## Experiment notes

Evaluate at the same coverage as LPEM. Report selective risk, AURC and the risk-coverage curve.

## Placement

Put cloned or vendored code in `third_party/selectivenet/src/`. That directory is
git-ignored, so official code is never committed by accident.
