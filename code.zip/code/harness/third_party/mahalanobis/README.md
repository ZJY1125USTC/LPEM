# Mahalanobis OOD

- **Official repository:** https://github.com/pokaxpoka/deep_Mahalanobis_detector
- **License status (checked 2026-10-22):** None declared
- **Paper:** Lee, Lee, Lee, Shin, Kim. A Simple Unified Framework for Detecting Out-of-Distribution Samples and Adversarial Attacks. NeurIPS 2018.

## Decision

**Re-implement from the paper.** The repository declares no license, so the code may not be copied or redistributed. The method itself is straightforward: class-conditional means and a shared (or class-specific) covariance, scored by Mahalanobis distance.

## Experiment notes

Use the negative Mahalanobis score as `predict_evidence` (higher = more in-distribution). Report both shared and class-specific covariance settings.

## Placement

Put cloned or vendored code in `third_party/mahalanobis/src/`. That directory is
git-ignored, so official code is never committed by accident.
