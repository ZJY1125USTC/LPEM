"""Frozen-backbone feature extraction for the vision datasets.

ResNet-18 (ImageNet, IMAGENET1K_V1), penultimate 512-d features, no fine-tuning.
The backbone is frozen and run in eval mode, so the features are a fixed
function of the raw pixels and cannot leak label information across folds.

Writes one .npz per dataset with keys X (float32, n x 512) and y (int64),
which is exactly what data.registry._load_npz expects.

Usage:
    python scripts/extract_features.py --dataset mnist cifar10 cub200 omniglot
    python scripts/extract_features.py --dataset all --out-dir E:/datasets/features
"""
from __future__ import annotations

import argparse
import glob
import gzip
import io
import os
import sys
import time

import numpy as np
import torch
from PIL import Image
from torch import nn
from torchvision.models import resnet18, ResNet18_Weights

MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)
SIZE = 224

VISUAL_ROOT = r"E:\datasets\data\07_visual"
OUT_DIR = r"E:\datasets\features"


# ------------------------------------------------------------------ helpers
def prep(im: Image.Image) -> torch.Tensor:
    """Centre-crop to a square, resize to 224, ImageNet-normalise."""
    im = im.convert("RGB")
    w, h = im.size
    if w != h:
        s = min(w, h)
        left, top = (w - s) // 2, (h - s) // 2
        im = im.crop((left, top, left + s, top + s))
    im = im.resize((SIZE, SIZE), Image.BILINEAR)
    a = np.asarray(im, dtype=np.float32) / 255.0
    a = (a - MEAN) / STD
    return torch.from_numpy(a).permute(2, 0, 1)


# ------------------------------------------------------------ batch readers
def iter_mnist(raw: str, batch: int = 1024):
    """Standard IDX files; train/ and t10k/ prefixes differ, so name both."""
    for split in ("train", "t10k"):
        with gzip.open(os.path.join(raw, f"{split}-images-idx3-ubyte.gz")) as f:
            buf = f.read()
        n = int.from_bytes(buf[4:8], "big")
        images = np.frombuffer(buf[16:], dtype=np.uint8).reshape(n, 28, 28)
        with gzip.open(os.path.join(raw, f"{split}-labels-idx1-ubyte.gz")) as f:
            lbuf = f.read()
        labels = np.frombuffer(lbuf[8:], dtype=np.uint8).astype(np.int64)
        for i in range(0, n, batch):
            j = min(i + batch, n)
            yield [Image.fromarray(images[k]) for k in range(i, j)], labels[i:j]


def iter_parquet(paths, col: str, batch: int = 512):
    import pyarrow.parquet as pq

    for p in paths:
        pf = pq.ParquetFile(p)
        for b in pf.iter_batches(batch_size=batch, columns=[col, "label"]):
            d = b.to_pydict()
            imgs = [Image.open(io.BytesIO(rec["bytes"])) for rec in d[col]]
            yield imgs, np.asarray(d["label"], dtype=np.int64)


def iter_omniglot(root: str, batch: int = 512):
    """One class per leaf directory that directly contains png files.

    The archive nests ``images_background/images_background/<script>/<char>``,
    so the number of container levels is not fixed; walking to the leaves is
    robust to that.
    """
    leaves = []
    for dirpath, _dirnames, filenames in os.walk(root):
        if any(f.lower().endswith(".png") for f in filenames):
            leaves.append(dirpath)
    leaves.sort()

    imgs, labels = [], []
    for label, cdir in enumerate(leaves):
        for fn in sorted(os.listdir(cdir)):
            if not fn.lower().endswith(".png"):
                continue
            imgs.append(os.path.join(cdir, fn))
            labels.append(label)
            if len(imgs) >= batch:
                # .copy() forces the decode and releases the file handle
                yield ([Image.open(p).copy() for p in imgs],
                       np.asarray(labels, dtype=np.int64))
                imgs, labels = [], []
    if imgs:
        yield ([Image.open(p).copy() for p in imgs],
               np.asarray(labels, dtype=np.int64))
    print(f"  omniglot: {len(leaves)} classes, root={root}")


def iter_imagenette(root: str, batch: int = 512):
    """ImageNet-10 subset (Imagenette): 10 ImageNet classes, ~13k images.

    Class folders are shared by the ``train`` and ``val`` split, so the label
    map is built once from ``train`` to keep the two splits aligned.
    """
    train = os.path.join(root, "train")
    classes = sorted(d for d in os.listdir(train)
                     if os.path.isdir(os.path.join(train, d)))
    index = {c: i for i, c in enumerate(classes)}

    imgs, labels = [], []
    for split in ("train", "val"):
        sdir = os.path.join(root, split)
        if not os.path.isdir(sdir):
            continue
        for c in classes:
            cdir = os.path.join(sdir, c)
            if not os.path.isdir(cdir):
                continue
            for fn in sorted(os.listdir(cdir)):
                if not fn.lower().endswith((".jpeg", ".jpg", ".png")):
                    continue
                imgs.append(os.path.join(cdir, fn))
                labels.append(index[c])
                if len(imgs) >= batch:
                    yield ([Image.open(p_).copy() for p_ in imgs],
                           np.asarray(labels, dtype=np.int64))
                    imgs, labels = [], []
    if imgs:
        yield ([Image.open(p_).copy() for p_ in imgs],
               np.asarray(labels, dtype=np.int64))
    print(f"  imagenette: {len(classes)} classes, root={root}")


# ----------------------------------------------------------------- main run
def extract(name: str, it, out_path: str, model, device: str):
    feats, labels = [], []
    n = 0
    t0 = time.time()
    for imgs, ys in it:
        batch = torch.stack([prep(im) for im in imgs]).to(device, non_blocking=True)
        with torch.no_grad(), torch.autocast("cuda", dtype=torch.float16):
            f = model(batch)
        feats.append(f.float().cpu().numpy())
        labels.append(ys)
        n += len(ys)
        if n % 5120 < len(ys):
            rate = n / max(time.time() - t0, 1e-6)
            print(f"  {name}: {n} images  ({rate:.0f}/s)", end="\r")
    X = np.concatenate(feats).astype(np.float32)
    y = np.concatenate(labels).astype(np.int64)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    np.savez(out_path, X=X, y=y)
    print(f"\n  {name}: X={X.shape} y={y.shape} classes={len(np.unique(y))} "
          f"-> {out_path}")
    return X.shape, len(np.unique(y))


def build(dataset: str, out_dir: str):
    if dataset == "mnist":
        raw = os.path.join(VISUAL_ROOT, "mnist", "raw")
        return iter_mnist(raw), os.path.join(out_dir, "mnist.npz")
    if dataset == "cifar10":
        raw = os.path.join(VISUAL_ROOT, "cifar10", "raw")
        paths = sorted(glob.glob(os.path.join(raw, "*.parquet")))
        return iter_parquet(paths, "img"), os.path.join(out_dir, "cifar10.npz")
    if dataset == "cub200":
        raw = os.path.join(VISUAL_ROOT, "cub200_2011", "raw")
        paths = sorted(glob.glob(os.path.join(raw, "*.parquet")))
        return iter_parquet(paths, "image"), os.path.join(out_dir, "cub200.npz")
    if dataset == "omniglot":
        root = os.path.join(VISUAL_ROOT, "omniglot", "extracted")
        return iter_omniglot(root), os.path.join(out_dir, "omniglot.npz")
    if dataset == "imagenette":
        base = os.path.join(VISUAL_ROOT, "imagenette", "extracted")
        nested = os.path.join(base, "imagenette2-320")
        root = nested if os.path.isdir(nested) else base
        return iter_imagenette(root), os.path.join(out_dir, "imagenette.npz")
    raise ValueError(f"unknown dataset {dataset!r}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", nargs="+", default=["all"])
    ap.add_argument("--out-dir", default=OUT_DIR)
    args = ap.parse_args()

    names = (["mnist", "cifar10", "cub200", "omniglot", "imagenette"]
             if args.dataset == ["all"] else args.dataset)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1)
    model.fc = nn.Identity()
    model.eval().to(device)
    print(f"backbone resnet18, device={device}, out_dim=512")

    summary = []
    for name in names:
        print(f"[{name}]")
        it, out_path = build(name, args.out_dir)
        shape, k = extract(name, it, out_path, model, device)
        summary.append((name, shape, k))

    print("\n=== summary ===")
    for name, shape, k in summary:
        print(f"  {name:10s} X={shape} classes={k}")


if __name__ == "__main__":
    main()
