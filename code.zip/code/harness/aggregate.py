"""Aggregate results: mean +/- std, average ranks, Friedman + Nemenyi CD.

All ranking respects metric direction (see metrics/registry.py). NLL / Brier /
ECE / MCE / AURC / selective risk are lower-is-better and would be inverted if
ranked with a single fixed rule.
"""
import glob, os
import numpy as np
import pandas as pd
from scipy.stats import friedmanchisquare

from metrics.registry import higher_is_better

# Nemenyi critical values for alpha = 0.05 (two-tailed), k = number of methods
Q_ALPHA_05 = {2: 1.960, 3: 2.343, 4: 2.569, 5: 2.728, 6: 2.850, 7: 2.949,
              8: 3.031, 9: 3.102, 10: 3.164, 11: 3.219, 12: 3.268}


def load_results(results_dir="results"):
    files = sorted(glob.glob(os.path.join(results_dir, "*.csv")))
    if not files:
        return pd.DataFrame()
    return pd.concat([pd.read_csv(f) for f in files], ignore_index=True)


def summarize(df, metric="acc"):
    return (df.groupby(["dataset", "method"])[metric]
              .agg(["mean", "std", "count"])
              .reset_index())


def avg_ranks(df, metric="acc"):
    """Average rank across datasets. Rank 1 is best, honouring metric direction."""
    hib = higher_is_better(metric)
    s = summarize(df, metric)
    s["rank"] = s.groupby("dataset")["mean"].rank(
        ascending=not hib, method="average"
    )
    return s.groupby("method")["rank"].agg(["mean", "std", "count"]).sort_values("mean")


def friedman_and_cd(df, metric="acc", alpha=0.05):
    """Friedman test on per-dataset ranks + Nemenyi critical difference."""
    hib = higher_is_better(metric)
    s = summarize(df, metric)
    wide = s.pivot(index="dataset", columns="method", values="mean").dropna()
    if wide.shape[0] < 3 or wide.shape[1] < 3:
        raise ValueError("Need >= 3 datasets and >= 3 methods for Friedman/Nemenyi")

    ranks = wide.rank(axis=1, ascending=not hib, method="average")
    stat, p = friedmanchisquare(*[ranks[c].values for c in ranks.columns])
    k, N = ranks.shape[1], ranks.shape[0]
    q = Q_ALPHA_05.get(k, 3.268)
    cd = q * np.sqrt(k * (k + 1) / (6.0 * N))
    return dict(metric=metric, statistic=float(stat), p_value=float(p),
                k=int(k), n_datasets=int(N), cd=float(cd),
                mean_ranks=ranks.mean().sort_values().to_dict())


def win_tie_loss(df, metric="acc", reference="lpem"):
    """Count wins / ties / losses of `reference` against every other method."""
    hib = higher_is_better(metric)
    s = summarize(df, metric)
    wide = s.pivot(index="dataset", columns="method", values="mean").dropna()
    if reference not in wide.columns:
        raise ValueError(f"{reference!r} not in results")
    out = {}
    for m in wide.columns:
        if m == reference:
            continue
        diff = wide[reference] - wide[m]
        if not hib:
            diff = -diff
        tol = 1e-9
        out[m] = dict(win=int((diff > tol).sum()),
                      tie=int((diff.abs() <= tol).sum()),
                      loss=int((diff < -tol).sum()))
    return out


def plot_cd(result, out_path="figures/cd_diagram.png"):
    """Draw a Nemenyi critical-difference diagram from friedman_and_cd()."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    ranks = result["mean_ranks"]
    cd = result["cd"]
    names = list(ranks.keys())
    vals = np.array([ranks[n] for n in names])

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    fig, ax = plt.subplots(figsize=(9, 1.2 + 0.45 * len(names)))
    ax.set_xlim(0.5, max(vals.max(), 1) + 1.0)
    ax.set_ylim(0, len(names) + 1.5)
    ax.axis("off")

    ax.hlines(1.0, 0.5, max(vals.max(), 1) + 1.0, color="black", lw=1.2)
    for tick in np.arange(1, int(max(vals.max(), 1)) + 2):
        ax.vlines(tick, 0.92, 1.08, color="black", lw=1.0)
        ax.text(tick, 0.70, str(tick), ha="center", va="top", fontsize=10)

    order = np.argsort(vals)
    used = []
    for slot, i in enumerate(order):
        y = 1.6 + slot * 0.42
        ax.plot([vals[i], vals[i]], [1.08, y - 0.06], color="black", lw=1.0)
        ax.text(vals[i] + 0.06, y, f"{names[i]} ({vals[i]:.2f})",
                ha="left", va="center", fontsize=9)
        used.append(vals[i])

    ax.hlines(0.45, 0.5, 0.5 + cd, color="black", lw=2.5)
    ax.text(0.5 + cd / 2, 0.28, f"CD = {cd:.2f}", ha="center", va="top", fontsize=9)
    ax.set_title(f"Nemenyi CD, {result['metric']}, k={result['k']}, "
                 f"N={result['n_datasets']}, p={result['p_value']:.3g}",
                 fontsize=10, loc="left")
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("wrote", out_path)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--metric", default="acc")
    ap.add_argument("--cd-figure", default=None)
    args = ap.parse_args()

    df = load_results(args.results)
    if df.empty:
        raise SystemExit(f"No csv files in {args.results!r}")
    print(f"rows: {len(df)}")
    print("\naverage ranks:")
    print(avg_ranks(df, args.metric).to_string())
    res = friedman_and_cd(df, args.metric)
    print("\nFriedman / Nemenyi:")
    for k, v in res.items():
        print(f"  {k}: {v}")
    print("\nwin / tie / loss vs lpem:")
    try:
        print(win_tie_loss(df, args.metric))
    except ValueError as e:
        print("  skipped:", e)
    if args.cd_figure:
        plot_cd(res, args.cd_figure)
