"""Ablation sweep for LPEM: full / no_temp / single_proto / fixed_metric / no_reg.

Each variant re-uses the tuned per-dataset configuration in datasets.yaml
(n_k, rank, evidence) and only switches off the component under test.
Resumable: a (dataset, variant) pair is skipped when its CSV is complete.
"""
from __future__ import annotations
import argparse
import os
import time

import pandas as pd

from config import Config
from data.registry import load_config, select_specs
from runner import run_one

VARIANTS = {
    "full": {},
    "no_temp": {"temperature": False},
    "single_proto": {"n_k": 1},
    "fixed_metric": {"learn_metric": False, "metric_init": "pca_whiten"},
    "fixed_identity": {"learn_metric": False, "metric_init": "identity"},
    "shared_metric": {"share_metric": True},
    "no_reg": {"lambda_sep": 0.0, "lambda_sm": 0.0, "lambda_ent": 0.0},
}

DEFAULT_DATASETS = [
    "wine", "iris", "seeds", "ecoli", "parkinsons",
    "heart_disease", "breast_cancer", "thyroid_disease", "dermatology", "mammographic_mass",
    "german_credit", "australian_credit", "bank_marketing",
    "vehicle", "segment", "vowel", "optical_digits",
    "adult", "spambase", "har",
    "pima", "credit_card_fraud", "lending_club", "home_credit",
    "occupancy_detection", "gas_sensor_drift",
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="+", default=DEFAULT_DATASETS)
    ap.add_argument("--variants", nargs="+", default=list(VARIANTS))
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    ap.add_argument("--results-dir", default="results_ablation")
    ap.add_argument("--config", default="datasets.yaml")
    args = ap.parse_args()

    cfg_yaml = load_config(args.config)
    root = cfg_yaml["root"]
    specs = {s["name"]: s for s in select_specs(cfg_yaml, names=args.datasets)}
    os.makedirs(args.results_dir, exist_ok=True)

    total = len(args.datasets) * len(args.variants)
    done = 0
    started = time.time()
    print(f"[ablation] {len(args.datasets)} datasets x {len(args.variants)} "
          f"variants x {args.folds} folds x {len(args.seeds)} seeds "
          f"= {total} jobs", flush=True)

    for ds in args.datasets:
        spec = specs[ds]
        n_splits = args.folds
        for variant in args.variants:
            done += 1
            out = os.path.join(args.results_dir, f"{ds}__lpem_{variant}.csv")
            if os.path.exists(out):
                try:
                    n = len(pd.read_csv(out))
                except Exception:
                    n = -1
                if n == n_splits * len(args.seeds):
                    print(f"[skip] {done}/{total} {ds}/{variant} (complete)",
                          flush=True)
                    continue

            kwargs = dict(spec.get("lpem", {}))
            kwargs.update(VARIANTS[variant])
            spec2 = dict(spec)
            spec2["lpem"] = kwargs

            raw_dir = os.path.join(args.results_dir, f"_raw_{variant}")
            cfg = Config(
                n_splits=n_splits,
                force_n_splits=True,
                seeds=tuple(args.seeds),
                val_fraction=0.2,
                smote=bool(spec.get("smote")),
                config_path=args.config,
                data_root=root,
                results_dir=raw_dir,
                pred_dir=os.path.join("predictions_ablation", variant),
            )
            t0 = time.time()
            try:
                df = run_one(spec2, "lpem", cfg, verbose=False)
                df["method"] = f"lpem_{variant}"
                df.to_csv(out, index=False)
                print(f"[ok]   {done}/{total} {ds}/{variant} "
                      f"{len(df)} rows in {time.time()-t0:.1f}s", flush=True)
            except Exception as e:
                print(f"[fail] {done}/{total} {ds}/{variant} "
                      f"{type(e).__name__}: {str(e)[:160]}", flush=True)

    print(f"[ablation] done in {(time.time()-started)/3600:.2f} h", flush=True)


if __name__ == "__main__":
    main()
