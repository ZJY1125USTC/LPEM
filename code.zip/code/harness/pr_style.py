# -*- coding: utf-8 -*-
"""Shared Pattern-Recognition figure style for the LPEM manuscript.

All chapter-6 and appendix-B figures are drawn through this module so that
fonts, colours, line styles and marker shapes stay identical across the paper.
"""
import matplotlib as mpl
import matplotlib.pyplot as plt


def set_pr_style():
    mpl.rcParams.update({
        'font.family': 'serif',
        'font.serif': ['Times New Roman', 'DejaVu Serif'],
        'font.size': 9,
        'axes.titlesize': 10,
        'axes.labelsize': 9,
        'xtick.labelsize': 8,
        'ytick.labelsize': 8,
        'legend.fontsize': 8,
        'axes.linewidth': 0.8,
        'xtick.major.width': 0.8,
        'ytick.major.width': 0.8,
        'xtick.minor.width': 0.6,
        'ytick.minor.width': 0.6,
        'xtick.major.size': 3.2,
        'ytick.major.size': 3.2,
        'xtick.minor.size': 1.8,
        'ytick.minor.size': 1.8,
        'xtick.direction': 'out',
        'ytick.direction': 'out',
        'figure.dpi': 300,
        'savefig.dpi': 300,
        'savefig.bbox': 'tight',
        'savefig.pad_inches': 0.02,
        'mathtext.fontset': 'stix',
        'pdf.fonttype': 42,
        'ps.fonttype': 42,
    })


COLORS = {
    'LPEM': '#2c7fb8',
    'CRC': '#d62728',
    'Dirichlet': '#ff7f0e',
    'SelectiveNet': '#2ca02c',
    'Mahalanobis': '#7f7f7f',
    'DUQ': '#bcbd22',
    'wkNN': '#9467bd',
}

LINESTYLES = {
    'LPEM': '-',
    'CRC': '-',
    'Dirichlet': '-',
    'SelectiveNet': '-',
    'Mahalanobis': '--',
    'DUQ': ':',
    'wkNN': '-',
}

LINEWIDTHS = {
    'LPEM': 2.2,
    'CRC': 1.5,
    'Dirichlet': 1.5,
    'SelectiveNet': 1.5,
    'Mahalanobis': 1.2,
    'DUQ': 1.2,
    'wkNN': 1.5,
}

# Distinct markers carry the identity where several methods share a solid line.
MARKERS = {
    'LPEM': 'o',
    'CRC': 's',
    'Dirichlet': '^',
    'SelectiveNet': 'D',
    'Mahalanobis': 'x',
    'DUQ': '+',
    'wkNN': 'v',
}

MARKERSIZE = {
    'LPEM': 3.4,
    'CRC': 3.0,
    'Dirichlet': 3.0,
    'SelectiveNet': 2.9,
    'Mahalanobis': 3.2,
    'DUQ': 3.6,
    'wkNN': 3.0,
}

# Manuscript order: strongest competitors first, reference baselines last.
ORDER = ['LPEM', 'CRC', 'Dirichlet', 'SelectiveNet', 'Mahalanobis', 'DUQ', 'wkNN']

KEY = {
    'LPEM': 'lpem',
    'CRC': 'crc',
    'Dirichlet': 'dirichlet',
    'SelectiveNet': 'selective',
    'Mahalanobis': 'mahalanobis',
    'DUQ': 'duq',
    'wkNN': 'wknn',
}


def style_of(name):
    return dict(color=COLORS[name], ls=LINESTYLES[name], lw=LINEWIDTHS[name],
                marker=MARKERS[name], ms=MARKERSIZE[name])


def legend_handles(names=None, marker_every=None):
    from matplotlib.lines import Line2D
    names = names or ORDER
    out = []
    for n in names:
        st = style_of(n)
        out.append(Line2D([0], [0], color=st['color'], ls=st['ls'], lw=st['lw'],
                          marker=st['marker'], markersize=st['ms'],
                          markeredgewidth=0.6, label=n))
    return out