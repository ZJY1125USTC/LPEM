"""OOD evaluation with the leave-class protocol.

Train on a subset of classes (in-distribution), then score held-out classes as
out-of-distribution. This keeps the feature space identical, which cross-dataset
OOD cannot guarantee for tabular data with different dimensionality.

The model is fitted once per (dataset, method, seed) and all requested scores
are derived from the same fit, so comparing scores costs nothing extra.

Usage
-----
python ood_eval.py --dataset optical_digits --holdout 2 --method mahalanobis
python ood_eval.py --dataset segment --holdout 2 --method lpem --seeds 0 1 2
python ood_eval.py --dataset optical_digits segment vehicle --holdout 2 \
    --method lpem duq mahalanobis --score evidence proba margin --seeds 0 1 2 3 4
"""
from __future__ import annotations
import argparse
import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GroupShuffleSplit

from config import Config
from data.registry import load_config, select_specs, load_dataset
from data.preprocess import Preprocessor
from metrics.ood import auroc, fpr_at_95_tpr
from runner import get_method


def score_vector(model, X, kind):
    """Turn a fitted model and a design matrix into an OOD score.

    evidence : the method's native in-distribution evidence
    proba    : maximum posterior probability
    margin   : top-1 minus top-2 posterior probability
    """
    if kind == "negdist":
        return np.asarray(model.predict_negdist(X), dtype=np.float64)
    if kind == "evidence":
        return np.asarray(model.predict_evidence(X), dtype=np.float64)
    P = np.asarray(model.predict_proba(X), dtype=np.float64)
    if kind == "proba" or P.shape[1] < 2:
        return P.max(axis=1)
    if kind == "margin":
        S = np.sort(P, axis=1)
        return S[:, -1] - S[:, -2]
    raise ValueError(f"unknown score {kind!r}")


def run(dataset, holdout, method, cfg, holdout_classes=None, seed=0,
        scores=("evidence",), lpem_kwargs=None):
    cfg_yaml = load_config(cfg.config_path)
    spec = select_specs(cfg_yaml, names=[dataset])[0]
    ds = load_dataset(spec, root=cfg.data_root)

    counts = np.bincount(ds.y)
    present = np.flatnonzero(counts)
    if holdout_classes:
        ood_classes = np.asarray(holdout_classes, dtype=int)
    else:
        # Take classes from the rarest upwards. When several classes tie for
        # the rarest rank the tie is broken by the seed: on vowel all eleven
        # classes have exactly 90 samples, and a fixed tie-break would always
        # hold out the same pair, which makes the result a property of the
        # label ordering rather than of the protocol.
        rng = np.random.default_rng(seed)
        order = present[np.argsort(counts[present], kind="stable")]
        chosen = []
        for c in np.unique(counts[order]):
            group = order[counts[order] == c]
            for g in rng.permutation(group):
                if len(chosen) < holdout:
                    chosen.append(int(g))
            if len(chosen) >= holdout:
                break
        ood_classes = np.asarray(chosen[:holdout], dtype=int)

    is_id = ~np.isin(ds.y, ood_classes)
    id_idx = np.flatnonzero(is_id)
    ood_idx = np.flatnonzero(~is_id)
    if len(ood_idx) == 0:
        raise ValueError(f"{dataset}: no samples left for OOD classes {ood_classes}")

    if ds.groups is not None:
        # vowel is grouped by speaker and har by subject; a row-wise split
        # would put the same speaker on both sides and inflate in-distribution
        # confidence, which biases the AUROC of every method in the same
        # direction. Split whole groups instead.
        gss = GroupShuffleSplit(n_splits=1, test_size=0.3, random_state=seed)
        a, b = next(gss.split(id_idx, ds.y[id_idx],
                              groups=ds.groups[id_idx]))
        tr, te = id_idx[a], id_idx[b]
        split_mode = "group"
    else:
        tr, te = train_test_split(id_idx, test_size=0.3,
                                  stratify=ds.y[id_idx], random_state=seed)
        split_mode = "stratified"

    pre = Preprocessor(ds.categorical_cols).fit(ds.X.iloc[tr])
    Xtr = pre.transform(ds.X.iloc[tr])
    ytr = ds.y[tr]
    Xte = pre.transform(ds.X.iloc[te])
    Xood = pre.transform(ds.X.iloc[ood_idx])

    kw = dict(lpem_kwargs or {}) if method == "lpem" else {}
    model = get_method(method, seed, **kw)
    model.fit(Xtr, ytr)

    out = []
    for score in scores:
        s_id = score_vector(model, Xte, score)
        s_ood = score_vector(model, Xood, score)
        out.append(dict(
            dataset=dataset, method=method, score=score, seed=seed,
            n_id_train=len(tr), n_id_test=len(te), n_ood=len(ood_idx),
            ood_classes=",".join(map(str, ood_classes.tolist())),
            split=split_mode,
            auroc=auroc(s_id, s_ood),
            fpr95=fpr_at_95_tpr(s_id, s_ood)))
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", nargs="+", required=True)
    ap.add_argument("--holdout", type=int, default=2,
                    help="number of rarest classes held out as OOD")
    ap.add_argument("--holdout-classes", type=int, nargs="+", default=None)
    ap.add_argument("--method", nargs="+", default=["mahalanobis"])
    ap.add_argument("--score", nargs="+", default=["evidence"],
                    choices=["evidence", "proba", "margin", "negdist"])
    ap.add_argument("--seeds", type=int, nargs="+", default=[0])
    ap.add_argument("--config", default="datasets.yaml")
    ap.add_argument("--results-dir", default="results_ood")
    args = ap.parse_args()

    cfg_yaml = load_config(args.config)
    cfg = Config(config_path=args.config, data_root=cfg_yaml["root"],
                 results_dir=args.results_dir)

    rows = []
    for dataset in args.dataset:
        spec = select_specs(cfg_yaml, names=[dataset])[0]
        lpem_kwargs = spec.get("lpem", {})
        for method in args.method:
            for seed in args.seeds:
                try:
                    got = run(dataset, args.holdout, method, cfg,
                              args.holdout_classes, seed,
                              scores=args.score, lpem_kwargs=lpem_kwargs)
                except Exception as exc:  # keep the sweep going
                    print(f"[fail] {dataset}/{method} seed={seed}: {exc}")
                    continue
                rows.extend(got)
                for r in got:
                    print(f"{r['dataset']:16s} {r['method']:12s} "
                          f"{r['score']:8s} seed={seed} "
                          f"AUROC={r['auroc']:.4f} FPR95={r['fpr95']:.4f} "
                          f"(id_test={r['n_id_test']}, ood={r['n_ood']}, "
                          f"ood_classes={r['ood_classes']})")

    if not rows:
        raise SystemExit("no successful runs")

    df = pd.DataFrame(rows)
    os.makedirs(args.results_dir, exist_ok=True)
    out = os.path.join(args.results_dir, "ood_scores.csv")
    df.to_csv(out, index=False)
    print("\nwrote", out, f"({len(df)} rows)")

    print("\nmean over seeds")
    agg = (df.groupby(["dataset", "method", "score"])
             .agg(auroc=("auroc", "mean"), fpr95=("fpr95", "mean"),
                  n=("auroc", "size"))
             .reset_index().sort_values(["dataset", "auroc"], ascending=[True, False]))
    print(agg.to_string(index=False, float_format=lambda x: f"{x:.4f}"))
