"""Full experiment sweep with resume and retry.

Runs every selected dataset through every method, writing one CSV per
(dataset, method). Existing CSVs are skipped, so the script can be restarted
after a crash or a disconnected data drive.

Usage
-----
python run_all.py --groups tabular_small tabular_medical tabular_credit \
    tabular_multiclass tabular_large risk --folds 5 --seeds 0 1 2 3 4
"""
from __future__ import annotations
import argparse
import os
import time
import traceback

import pandas as pd

from config import Config
from data.registry import load_config, select_specs
from runner import run_one

# cheap post-hoc methods first so results accumulate early
METHOD_ORDER = ["mahalanobis", "wknn", "crc", "dirichlet", "lpem", "duq", "selective"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="datasets.yaml")
    ap.add_argument("--datasets", nargs="+", default=None)
    ap.add_argument("--groups", nargs="+", default=None)
    ap.add_argument("--methods", nargs="+", default=METHOD_ORDER)
    ap.add_argument("--exclude-groups", nargs="+", default=None,
                    help="skip datasets in these groups")
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
    ap.add_argument("--results-dir", default="results_final")
    ap.add_argument("--pred-dir", default="predictions_final")
    ap.add_argument("--retries", type=int, default=3)
    ap.add_argument("--retry-wait", type=float, default=30.0)
    args = ap.parse_args()

    cfg_yaml = load_config(args.config)
    root = cfg_yaml["root"]
    specs = select_specs(cfg_yaml, names=args.datasets, groups=args.groups)
    specs = [s for s in specs if s.get("status", "ready") == "ready"]
    if args.exclude_groups:
        excluded = set(args.exclude_groups)
        specs = [s for s in specs if s.get("group") not in excluded]

    # small datasets first: early feedback, and partial results stay useful
    def size_hint(s):
        p = s.get("path", "")
        return os.path.getsize(p) if os.path.isabs(p) and os.path.exists(p) else 0

    specs.sort(key=size_hint)
    methods = [m for m in args.methods]

    os.makedirs(args.results_dir, exist_ok=True)
    os.makedirs(args.pred_dir, exist_ok=True)

    total = len(specs) * len(methods)
    done = 0
    started = time.time()
    print(f"[start] {len(specs)} datasets x {len(methods)} methods = {total} jobs", flush=True)

    for spec in specs:
        n_splits = int(spec.get("n_splits") or args.folds)
        for method in methods:
            out = os.path.join(args.results_dir, f"{spec['name']}__{method}.csv")
            done += 1
            if os.path.exists(out):
                try:
                    n = len(pd.read_csv(out))
                except Exception:
                    n = -1
                if n == n_splits * len(args.seeds):
                    print(f"[skip] {done}/{total} {spec['name']}/{method} (complete)", flush=True)
                    continue
                print(f"[redo] {done}/{total} {spec['name']}/{method} (partial: {n} rows)", flush=True)

            cfg = Config(
                n_splits=args.folds,
                force_n_splits=True,
                seeds=tuple(args.seeds),
                val_fraction=0.2,
                smote=bool(spec.get("smote")),
                config_path=args.config,
                data_root=root,
                results_dir=args.results_dir,
                pred_dir=args.pred_dir,
            )

            ok = False
            for attempt in range(1, args.retries + 1):
                t0 = time.time()
                try:
                    df = run_one(spec, method, cfg, verbose=False)
                    print(f"[ok]   {done}/{total} {spec['name']}/{method} "
                          f"{len(df)} rows in {time.time()-t0:.1f}s", flush=True)
                    ok = True
                    break
                except Exception as e:
                    print(f"[fail] {done}/{total} {spec['name']}/{method} "
                          f"attempt {attempt}/{args.retries}: "
                          f"{type(e).__name__}: {str(e)[:120]}", flush=True)
                    traceback.print_exc()
                    if attempt < args.retries:
                        time.sleep(args.retry_wait)
            if not ok:
                print(f"[give-up] {spec['name']}/{method}", flush=True)

    print(f"[done] {total} jobs in {(time.time()-started)/3600:.2f} h", flush=True)


if __name__ == "__main__":
    main()
