"""Main loop: dataset x method x seed x fold -> results/*.csv + predictions/*.npz

Protocol
--------
outer:  split strategy from datasets.yaml (stratified / group / time series)
inner:  stratified split of the training fold into (sub-train, validation)
        - the preprocessor is fitted on the sub-train only
        - the method may early-stop on the validation split
refit:  preprocessor and method are refitted on the full training fold
        (validation is training data at that point, so this is not leakage)
checks: index / group / time / duplicate-row leakage, enforced per fold
"""
from __future__ import annotations
import argparse, os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from config import Config
from data.registry import load_config, select_specs, load_dataset
from data.splits import make_splits, apply_smote
from data.preprocess import Preprocessor
from data.leakage import check_fold, row_hashes, LeakageError
from metrics.classification import accuracy, macro_f1, nll, brier
from metrics.calibration import ece, mce
from metrics.selective import aurc, selective_risk_at_coverage

def get_method(name, seed, **kwargs):
    if name == "lpem":
        from methods.lpem import LPEM; return LPEM(seed=seed, **kwargs)
    if name == "duq":
        from methods.baselines.duq import DUQ; return DUQ()
    if name == "mahalanobis":
        from methods.baselines.mahalanobis import MahalanobisOOD; return MahalanobisOOD()
    if name == "dirichlet":
        from methods.baselines.dirichlet import DirichletCalibration; return DirichletCalibration()
    if name == "selective":
        from methods.baselines.selective import SelectiveNet; return SelectiveNet()
    if name == "crc":
        from methods.baselines.crc import ConformalRiskControl; return ConformalRiskControl()
    if name == "wknn":
        from methods.baselines.wknn import WeightedKNN; return WeightedKNN(**kwargs)
    raise ValueError(f"Unknown method {name!r}")


def inner_split(y, val_fraction, seed):
    idx = np.arange(len(y))
    if val_fraction <= 0 or len(y) < 20:
        return idx, np.array([], dtype=int)
    # a class with a single member cannot be stratified
    counts = np.bincount(y)
    if counts[counts > 0].min() < 2:
        return idx, np.array([], dtype=int)
    sub_tr, sub_val = train_test_split(
        idx, test_size=val_fraction, stratify=y, random_state=seed, shuffle=True
    )
    return sub_tr, sub_val


def evaluate(y_true, proba, score=None):
    # Selective metrics must use the same rejection statistic for every method,
    # otherwise the comparison is confounded by each method's own evidence
    # scale. Rank by posterior confidence for all methods; the method-specific
    # `score` is reserved for OOD detection.
    conf = proba.max(axis=1)
    sr, cov = selective_risk_at_coverage(y_true, proba, 0.8, score=conf)
    return dict(
        acc=accuracy(y_true, proba),
        macro_f1=macro_f1(y_true, proba),
        nll=nll(y_true, proba),
        brier=brier(y_true, proba),
        ece=ece(y_true, proba, 15),
        mce=mce(y_true, proba, 15),
        aurc=aurc(y_true, proba, score=conf),
        cov80=cov,
        selrisk80=sr,
    )


def _resolve_spec(spec_or_name, cfg):
    if isinstance(spec_or_name, dict):
        return spec_or_name
    config = load_config(cfg.config_path)
    matches = select_specs(config, names=[spec_or_name])
    if not matches:
        raise KeyError(f"dataset {spec_or_name!r} not in {cfg.config_path}")
    return matches[0]


def run_one(spec_or_name, method_name, cfg, verbose=True):
    spec = _resolve_spec(spec_or_name, cfg)
    ds = load_dataset(spec, root=cfg.data_root)
    name = ds.name

    split_strategy = spec.get("split") or "stratified_kfold"
    n_splits = (cfg.n_splits if cfg.force_n_splits
                else int(spec.get("n_splits") or cfg.n_splits))

    if cfg.strict_leakage_checks:
        # structural checks that do not depend on the fold
        if split_strategy == "group_kfold" and ds.groups is None:
            raise LeakageError(f"{name}: group_kfold requested but no group_col")
        if split_strategy == "time_series" and ds.times is None:
            raise LeakageError(f"{name}: time_series requested but no time_col")

    os.makedirs(cfg.results_dir, exist_ok=True)
    os.makedirs(cfg.pred_dir, exist_ok=True)
    rows = []
    leakage_warnings = []

    for seed in cfg.seeds:
        splits = make_splits(ds.y, groups=ds.groups, times=ds.times,
                             strategy=split_strategy, n_splits=n_splits, seed=seed)
        hashes = None
        if cfg.strict_leakage_checks and cfg.duplicate_check:
            if len(ds.X) <= cfg.duplicate_check_max_rows:
                hashes = row_hashes(ds.X)

        for fold, (tr, te) in enumerate(splits):
            if cfg.strict_leakage_checks:
                check_fold(name, ds.X, tr, te, groups=ds.groups,
                           times=ds.times if split_strategy == "time_series" else None,
                           hashes=hashes, fold_label=f"s{seed}f{fold}",
                           dup_policy=cfg.duplicate_policy,
                           dup_ratio_error=cfg.duplicate_ratio_error,
                           dup_count_error=cfg.duplicate_count_error,
                           warnings_out=leakage_warnings)

            tr_ds = ds.subset(tr)
            te_ds = ds.subset(te)

            # ---- inner validation split on raw features ----
            sub_tr, sub_val = inner_split(tr_ds.y, cfg.val_fraction, seed + fold)
            pre_inner = Preprocessor(
                tr_ds.categorical_cols,
                max_categorical_levels=cfg.max_categorical_levels,
            ).fit(tr_ds.X.iloc[sub_tr])
            X_sub_tr = pre_inner.transform(tr_ds.X.iloc[sub_tr])
            y_sub_tr = tr_ds.y[sub_tr]

            if len(sub_val) > 0:
                X_sub_val = pre_inner.transform(tr_ds.X.iloc[sub_val])
                y_sub_val = tr_ds.y[sub_val]
            else:
                X_sub_val = y_sub_val = None

            if cfg.smote:
                X_sub_tr, y_sub_tr = apply_smote(
                    X_sub_tr, y_sub_tr, cfg.smote_k_neighbors,
                    seed * 100 + fold,
                    majority_cap=spec.get("smote_majority_cap", cfg.smote_majority_cap),
                )

            lpem_kwargs = spec.get("lpem", {}) if method_name == "lpem" else {}
            model = get_method(method_name, seed, **lpem_kwargs)
            model.fit(X_sub_tr, y_sub_tr, X_sub_val, y_sub_val)

            # ---- refit on the full training fold ----
            if cfg.refit_on_full:
                pre = Preprocessor(
                    tr_ds.categorical_cols,
                    max_categorical_levels=cfg.max_categorical_levels,
                ).fit(tr_ds.X)
                X_tr = pre.transform(tr_ds.X)
                y_tr = tr_ds.y
                if cfg.smote:
                    X_tr, y_tr = apply_smote(
                        X_tr, y_tr, cfg.smote_k_neighbors,
                        seed * 100 + fold,
                        majority_cap=spec.get("smote_majority_cap",
                                              cfg.smote_majority_cap),
                    )
                model = model.refit(X_tr, y_tr)
            else:
                # Conservative variant: keep the model and scaler that were
                # fitted on the sub-train, so the validation rows are never seen.
                pre = pre_inner

            X_te = pre.transform(te_ds.X)
            proba = np.asarray(model.predict_proba(X_te), dtype=np.float64)
            score = np.asarray(model.predict_evidence(X_te), dtype=np.float64)

            if proba.ndim != 2:
                raise ValueError(f"{method_name}: proba must be 2-D, got {proba.shape}")
            if proba.shape[0] != len(te_ds.y):
                raise ValueError(f"proba has {proba.shape[0]} rows, expected {len(te_ds.y)}")

            # Map the method's class order onto the global 0..C-1 order. This
            # also covers folds in which a class is absent from training.
            classes = np.asarray(getattr(model, "classes_", np.arange(proba.shape[1])))
            if classes.ndim != 1 or len(classes) != proba.shape[1]:
                raise ValueError(
                    f"{method_name}: classes_ has {len(classes)} entries but "
                    f"proba has {proba.shape[1]} columns"
                )
            classes = classes.astype(int)
            if classes.min() < 0 or classes.max() >= ds.n_classes:
                raise ValueError(f"{method_name}: classes_ outside 0..{ds.n_classes-1}")
            full = np.zeros((len(proba), ds.n_classes), dtype=np.float64)
            full[:, classes] = proba
            proba = full
            if not np.all(np.isfinite(proba)):
                raise ValueError("proba contains NaN/Inf")
            proba = proba / np.clip(proba.sum(axis=1, keepdims=True), 1e-12, None)
            if not np.all(np.isfinite(score)):
                raise ValueError("evidence contains NaN/Inf")

            row = dict(dataset=name, method=method_name, seed=seed, fold=fold,
                       split=split_strategy, n_train=len(tr), n_test=len(te),
                       n_val=len(sub_val))
            row.update(evaluate(te_ds.y, proba, score))
            rows.append(row)

            np.savez_compressed(
                os.path.join(cfg.pred_dir, f"{name}__{method_name}__s{seed}_f{fold}.npz"),
                proba=proba,
                y_true=te_ds.y,
                score=score,
                classes=np.asarray(getattr(model, "classes_", np.arange(proba.shape[1]))),
                train_idx=tr,
                test_idx=te,
                val_idx=tr[sub_val] if len(sub_val) else np.array([], dtype=int),
            )

    if leakage_warnings:
        uniq = sorted(set(leakage_warnings))
        print(f"[leakage warnings] {name}: {len(uniq)} distinct")
        for msg in uniq[:3]:
            print("  -", msg)

    out = os.path.join(cfg.results_dir, f"{name}__{method_name}.csv")
    pd.DataFrame(rows).to_csv(out, index=False)
    if verbose:
        print(f"wrote {out}  ({len(rows)} rows, split={split_strategy}, "
              f"n_train={len(tr)}, n_test={len(te)})")
    return pd.DataFrame(rows)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="datasets.yaml")
    ap.add_argument("--datasets", nargs="+", default=None)
    ap.add_argument("--groups", nargs="+", default=None,
                    help="dataset groups, e.g. tabular_small risk")
    ap.add_argument("--methods", nargs="+", default=["crc"])
    ap.add_argument("--folds", type=int, default=None,
                    help="override n_splits for all datasets")
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1])
    ap.add_argument("--val-fraction", type=float, default=0.2)
    ap.add_argument("--no-refit", action="store_true")
    ap.add_argument("--smote", action="store_true",
                    help="force SMOTE on for every selected dataset")
    ap.add_argument("--no-smote", action="store_true",
                    help="disable SMOTE even if datasets.yaml enables it")
    ap.add_argument("--no-leakage-checks", action="store_true")
    ap.add_argument("--data-root", default=None,
                    help="override datasets.yaml:root")
    ap.add_argument("--results-dir", default="results")
    ap.add_argument("--pred-dir", default="predictions")
    args = ap.parse_args()

    config = load_config(args.config)
    data_root = args.data_root or config.get("root", ".")
    specs = select_specs(config, names=args.datasets, groups=args.groups)
    if not specs:
        raise SystemExit("no datasets selected")

    for spec in specs:
        if args.folds:
            spec = {**spec, "n_splits": args.folds}
        cfg = Config(
            n_splits=args.folds or int(spec.get("n_splits") or 5),
            force_n_splits=args.folds is not None,
            seeds=tuple(args.seeds),
            val_fraction=args.val_fraction,
            refit_on_full=not args.no_refit,
            smote=False if args.no_smote else (args.smote or bool(spec.get("smote"))),
            strict_leakage_checks=not args.no_leakage_checks,
            config_path=args.config,
            data_root=data_root,
            results_dir=args.results_dir,
            pred_dir=args.pred_dir,
        )
        for mt in args.methods:
            run_one(spec, mt, cfg)
