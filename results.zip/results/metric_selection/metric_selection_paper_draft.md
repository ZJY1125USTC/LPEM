# Training-time geometry as a prescreen for metric granularity

The preceding analysis asks whether a learned metric helps relative to a frozen metric. A second question concerns metric granularity: whether each class should have its own metric or one metric should be shared. We examine whether this choice can be anticipated from training-time class geometry.

For class $k$, let $\lambda_{k,j}$ be the eigenvalues of its covariance matrix and let $p_{k,j}=\lambda_{k,j}/\sum_j\lambda_{k,j}$. The effective rank is

$$
\mathrm{ER}_k=\exp\left(-\sum_j p_{k,j}\log p_{k,j}\right),
$$

and the effective-rank deficit is $D_k=1-\mathrm{ER}_k/d$. We summarise the class set by the sample-weighted mean deficit

$$
\bar D_w=\sum_{k=1}^K q_kD_k,\qquad q_k=\frac{n_k}{n},
$$

and by its class-conditional heterogeneity

$$
H_{\mathrm{ER}}=\sqrt{\sum_{k=1}^K q_k(D_k-\bar D_w)^2}.
$$

The covariance is estimated with Ledoit--Wolf shrinkage, and all quantities are computed inside the training fold. Per-dataset values are means over five folds and five seeds; folds are not treated as independent observations in any cross-dataset analysis.

On the twenty datasets with $d>r$, $H_{\mathrm{ER}}$ is positively associated with the accuracy advantage of the class-specific metric over the shared metric (Spearman $\rho=+0.52$, $p=0.018$, $n=20$). The bootstrap interval is $[+0.09,+0.81]$, and the leave-one-dataset-out correlation ranges from $+0.45$ to $+0.61$. The quartile summary is monotone in the sample mean: datasets in the lowest $H_{\mathrm{ER}}$ quartile average $-0.34$ percentage points, while those in the highest quartile average $+0.75$ percentage points (Table 1).

**Table 1.** Accuracy advantage of the class-specific metric over the shared metric by $H_{\mathrm{ER}}$ quartile.

| Quartile | Mean $H_{\mathrm{ER}}$ | Mean gain (pp) | Median gain (pp) | Positive / 5 |
|---|---:|---:|---:|---:|
| Q1 (low) | 0.010 | -0.341 | -0.130 | 2 |
| Q2 | 0.028 | 0.152 | 0.117 | 4 |
| Q3 | 0.073 | 0.433 | 0.368 | 3 |
| Q4 (high) | 0.119 | 0.754 | 0.694 | 4 |

The signal is not sufficient for a standalone predictor. Within the seventeen active i.i.d. datasets, the correlation is weaker and not significant ($\rho=+0.34$, $p=0.18$); removing `gas_sensor_drift` gives $\rho=+0.45$ and $p=0.056$. $H_{\mathrm{ER}}$ is also correlated with the number of classes ($\rho=+0.50$), and its rank-partial correlation given $K$ is $+0.38$ with $p=0.096$. Controlling for mean deficit, sample support and $K$ reduces the partial correlation to $+0.18$ ($p=0.44$). Thus, $H_{\mathrm{ER}}$ is not independent of other coarse problem characteristics.

The incremental regression evidence is similarly modest. Adding $H_{\mathrm{ER}}$ to a model with mean deficit, minimum sample support and $K$ reduces leave-one-dataset-out RMSE from 0.829 to 0.736 and raises $R^2$ from $-0.06$ to $0.17$. Mean absolute error, however, changes only from 0.585 to 0.586, and the rank correlation between predicted and observed gains is $0.38$ ($p=0.10$). Adding subspace heterogeneity or the Fisher ratio does not improve the regression.

A deliberately simple leave-one-dataset-out rule uses only the training-distribution percentile of $H_{\mathrm{ER}}$, with thresholds chosen from a fixed set of quartiles. It selects the class-specific metric on thirteen of twenty datasets, obtains a mean selected gain of $+0.31$ pp, and incurs regret $0.087$ pp. Always using the shared metric and always using the class-specific metric yield $0.000$ and $+0.250$ pp, with regrets $0.398$ and $0.148$ pp. The rule is therefore directionally useful, but its paired improvement over always using the class-specific metric is only $0.061$ pp, with bootstrap interval $[-0.121,+0.298]$.

Fold-level stability is moderate. The between-dataset intraclass correlation of $H_{\mathrm{ER}}$ is 0.54, and large datasets such as `home_credit` and `gas_sensor_drift` show substantial fold-to-fold variation. The Ledoit--Wolf estimator is used because the empirical-covariance version gives a weaker relation ($\rho=+0.37$, $p=0.11$). Excluding datasets with a minority class smaller than thirty rows changes the primary correlation only from $+0.52$ to $+0.52$.

We therefore treat training-time effective-rank heterogeneity as a prescreen rather than a complete selection rule. A large $H_{\mathrm{ER}}$ marks a regime in which separate metrics are more likely to pay for their additional parameters. The final choice should still be made on validation data among frozen, shared and class-specific metrics. The current evidence supports this bounded use of $H_{\mathrm{ER}}$; it does not support a universal threshold or the claim that the metric should be selected from geometry alone.
